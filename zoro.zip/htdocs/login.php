<?php
session_start();

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        if (!empty($email) && !empty($password)) {
            $stmt = $conn->prepare("SELECT user_id, company_name, contact_person_name, email, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                if ($password === $user['password']) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['company_name'] = $user['company_name'];
                    $_SESSION['contact_person_name'] = $user['contact_person_name'];
                    $_SESSION['email'] = $user['email'];
                    header("Location: index.php");
                    exit();
                } else { $error = "Invalid email or password!"; }
            } else { $error = "Invalid email or password!"; }
            $stmt->close();
        } else { $error = "Please fill in all fields!"; }
    }

    if (isset($_POST['signup'])) {
        $company_name = trim($_POST['company_name']);
        $store_address = trim($_POST['store_address']);
        $contact_person_name = trim($_POST['contact_person_name']);
        $phone_number = trim($_POST['phone_number']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST['confirm_password']);
        if (empty($company_name) || empty($email) || empty($password) || empty($confirm_password)) {
            $error = "Please fill in all required fields!";
        } elseif ($password !== $confirm_password) {
            $error = "Passwords do not match!";
        } else {
            $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $error = "Email already registered!";
            } else {
                $stmt = $conn->prepare("INSERT INTO users (company_name, store_address, contact_person_name, phone_number, email, password) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssss", $company_name, $store_address, $contact_person_name, $phone_number, $email, $password);
                if ($stmt->execute()) { $success = "Account created successfully! Please login."; }
                else { $error = "Registration failed: " . $stmt->error; }
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}

/* Decorative background */
body::before{content:'';position:fixed;top:-200px;right:-200px;width:600px;height:600px;border-radius:50%;background:radial-gradient(circle,rgba(200,150,12,.06) 0%,transparent 70%);pointer-events:none;}
body::after{content:'';position:fixed;bottom:-200px;left:-200px;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(160,106,0,.05) 0%,transparent 70%);pointer-events:none;}

.auth-wrapper{width:100%;max-width:460px;animation:fadeUp .5s ease both;}

.brand-header{text-align:center;margin-bottom:32px;}
.brand-logo{font-family:'Playfair Display',serif;font-size:32px;font-weight:900;color:var(--gold-dark);letter-spacing:3px;}
.brand-sub{font-size:11px;letter-spacing:3px;color:var(--text-muted);text-transform:uppercase;margin-top:4px;}
.brand-divider{width:40px;height:2px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));border-radius:2px;margin:12px auto 0;}

.auth-card{background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;box-shadow:0 20px 60px rgba(160,106,0,.12);}

.tab-bar{display:flex;border-bottom:1px solid var(--border);}
.tab-btn{flex:1;padding:16px;background:none;border:none;font-family:'Lato',sans-serif;font-size:13px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--text-muted);cursor:pointer;transition:all .2s;position:relative;}
.tab-btn::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));transform:scaleX(0);transition:transform .2s;}
.tab-btn.active{color:var(--gold-dark);}
.tab-btn.active::after{transform:scaleX(1);}
.tab-btn:hover:not(.active){color:var(--text);background:var(--bg);}

.form-body{padding:32px;}
.form-panel{display:none;}
.form-panel.active{display:block;animation:fadeUp .3s ease both;}

.form-group{margin-bottom:18px;}
.form-group label{display:block;margin-bottom:7px;font-size:12px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--gold-dark);}
.form-group input{width:100%;padding:12px 16px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:14px;color:var(--text);background:var(--bg);transition:border-color .2s,box-shadow .2s;}
.form-group input:focus{outline:none;border-color:var(--gold);box-shadow:0 0 0 3px rgba(200,150,12,.12);}
.form-group input::placeholder{color:var(--gold-muted);}

.input-icon-wrap{position:relative;}
.input-icon-wrap input{padding-left:42px;}
.input-icon-wrap .icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--gold-muted);font-size:14px;}

.submit-btn{width:100%;padding:13px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:8px;font-family:'Lato',sans-serif;font-size:14px;font-weight:700;letter-spacing:.5px;cursor:pointer;transition:opacity .2s,transform .1s;margin-top:6px;}
.submit-btn:hover{opacity:.9;transform:translateY(-1px);}
.submit-btn:active{transform:translateY(0);}

.msg{padding:13px 16px;border-radius:8px;margin-bottom:20px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px;}
.msg.error{background:#fff0f0;border:1px solid #f5c6cb;color:#a00;}
.msg.success{background:#f0fff4;border:1px solid var(--gold-pale);color:var(--gold-dark);}

.back-link{text-align:center;margin-top:20px;}
.back-link a{color:var(--text-muted);font-size:13px;text-decoration:none;transition:color .2s;}
.back-link a:hover{color:var(--gold-dark);}

.divider-text{text-align:center;margin:20px 0;color:var(--text-muted);font-size:12px;position:relative;}
.divider-text::before,.divider-text::after{content:'';position:absolute;top:50%;width:42%;height:1px;background:var(--border);}
.divider-text::before{left:0;}
.divider-text::after{right:0;}

@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
</style>
</head>
<body>

<div class="auth-wrapper">
    <div class="brand-header">
        <div class="brand-logo">ZORO</div>
        <div class="brand-sub">International</div>
        <div class="brand-divider"></div>
    </div>

    <?php if ($error): ?>
        <div class="msg error"><i class="fas fa-exclamation-circle"></i><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="msg success"><i class="fas fa-check-circle"></i><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <div class="auth-card">
        <div class="tab-bar">
            <button class="tab-btn <?php echo !isset($_POST['signup']) ? 'active' : ''; ?>" onclick="showTab('login')">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
            <button class="tab-btn <?php echo isset($_POST['signup']) ? 'active' : ''; ?>" onclick="showTab('signup')">
                <i class="fas fa-user-plus"></i> Sign Up
            </button>
        </div>

        <div class="form-body">
            <!-- LOGIN -->
            <div id="panel-login" class="form-panel <?php echo !isset($_POST['signup']) ? 'active' : ''; ?>">
                <form method="POST">
                    <div class="form-group">
                        <label>Email Address</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-envelope icon"></i>
                            <input type="email" name="email" placeholder="you@company.com" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-lock icon"></i>
                            <input type="password" name="password" placeholder="••••••••" required>
                        </div>
                    </div>
                    <button type="submit" name="login" class="submit-btn">
                        <i class="fas fa-arrow-right"></i> &nbsp;Sign In
                    </button>
                </form>
            </div>

            <!-- SIGNUP -->
            <div id="panel-signup" class="form-panel <?php echo isset($_POST['signup']) ? 'active' : ''; ?>">
                <form method="POST">
                    <div class="form-group">
                        <label>Company Name <span style="color:#c00">*</span></label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-building icon"></i>
                            <input type="text" name="company_name" placeholder="Your Company Ltd." required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Store Address</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-map-marker-alt icon"></i>
                            <input type="text" name="store_address" placeholder="Street, City, State">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Contact Person</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-user icon"></i>
                            <input type="text" name="contact_person_name" placeholder="Full name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-phone icon"></i>
                            <input type="text" name="phone_number" placeholder="+91 00000 00000">
                        </div>
                    </div>
                    <div class="divider-text">Account Details</div>
                    <div class="form-group">
                        <label>Email Address <span style="color:#c00">*</span></label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-envelope icon"></i>
                            <input type="email" name="email" placeholder="you@company.com" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Password <span style="color:#c00">*</span></label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-lock icon"></i>
                            <input type="password" name="password" placeholder="Min. 6 characters" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password <span style="color:#c00">*</span></label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-lock icon"></i>
                            <input type="password" name="confirm_password" placeholder="Repeat password" required>
                        </div>
                    </div>
                    <button type="submit" name="signup" class="submit-btn">
                        <i class="fas fa-user-plus"></i> &nbsp;Create Account
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="back-link">
        <a href="index.php"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </div>
</div>

<script>
function showTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.form-panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`[onclick="showTab('${tab}')"]`).classList.add('active');
    document.getElementById('panel-' + tab).classList.add('active');
}
</script>
</body>
</html>
