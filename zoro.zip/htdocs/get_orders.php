<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$user_email = $_SESSION['email'];
$query = "SELECT o.*, p.product_name, p.brand, p.image_path FROM orders o LEFT JOIN products p ON o.product_id = p.product_id WHERE o.email = ? ORDER BY o.order_datetime DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$total_orders = $result->num_rows;

$total_spent = 0;
$all_orders = [];
while($o = $result->fetch_assoc()) { $all_orders[] = $o; $total_spent += ($o['price']??0)*$o['quantity']; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Orders — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);box-shadow:0 2px 16px rgba(160,106,0,.07);}
.header-inner{max-width:1100px;margin:auto;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;}
.logo-name{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;text-decoration:none;}
.nav-links{display:flex;gap:18px;}
.nav-links a{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;display:flex;align-items:center;gap:5px;}
.nav-links a:hover{color:var(--gold-dark);}

.page-wrap{max-width:1100px;margin:36px auto;padding:0 24px;}
.page-title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--text);margin-bottom:6px;}
.page-sub{font-size:13px;color:var(--text-muted);margin-bottom:28px;}

.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:28px;}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px 22px;position:relative;overflow:hidden;}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));}
.stat-num{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--gold-dark);}
.stat-label{font-size:12px;color:var(--text-muted);letter-spacing:.3px;margin-top:4px;}

.orders-grid{display:flex;flex-direction:column;gap:16px;}
.order-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:box-shadow .2s,transform .2s;animation:fadeUp .4s ease both;}
.order-card:hover{box-shadow:0 8px 32px rgba(160,106,0,.1);transform:translateY(-2px);}
.order-card-head{padding:14px 20px;background:linear-gradient(135deg,rgba(160,106,0,.05),rgba(200,150,12,.08));border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;}
.order-id{font-weight:700;color:var(--text);font-size:14px;}
.order-date{font-size:12px;color:var(--text-muted);}
.payment-badge{padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;background:var(--gold-pale);color:var(--gold-dark);border:1px solid var(--gold-muted);}
.order-card-body{padding:18px 20px;display:flex;gap:16px;align-items:center;}
.order-img{width:72px;height:72px;object-fit:cover;border-radius:10px;border:1px solid var(--border);}
.order-img-placeholder{width:72px;height:72px;background:var(--bg);border:1px solid var(--border);border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--gold-muted);font-size:22px;}
.order-info{flex:1;}
.order-product{font-family:'Playfair Display',serif;font-size:16px;font-weight:700;color:var(--text);margin-bottom:4px;}
.order-brand{font-size:12px;color:var(--text-muted);margin-bottom:8px;}
.order-meta{display:flex;gap:20px;font-size:13px;}
.order-meta span{color:var(--text-muted);}
.order-meta strong{color:var(--text);}
.order-total{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--gold-dark);flex-shrink:0;}

.empty-state{text-align:center;padding:60px 24px;background:var(--surface);border:1px solid var(--border);border-radius:16px;}
.empty-icon{font-size:48px;color:var(--gold-pale);margin-bottom:16px;}
.empty-state h3{font-family:'Playfair Display',serif;font-size:22px;color:var(--text);margin-bottom:8px;}
.empty-state p{color:var(--text-muted);margin-bottom:24px;}
.btn-shop{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--gold-dark);color:#fff;border-radius:7px;text-decoration:none;font-weight:700;}
.btn-shop:hover{background:var(--gold);}

@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
.order-card:nth-child(odd){animation-delay:.03s;}
.order-card:nth-child(even){animation-delay:.07s;}
</style>
</head>
<body>
<div class="top-bar">✦ ZORO International ✦</div>
<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo-name">ZORO</a>
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
            <a href="cart.php"><i class="fas fa-shopping-bag"></i> Cart</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</header>

<div class="page-wrap">
    <h1 class="page-title">My Orders</h1>
    <p class="page-sub">Order history for <?php echo htmlspecialchars($user_email); ?></p>

    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-num"><?php echo $total_orders; ?></div>
            <div class="stat-label">Total Orders</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">₹<?php echo number_format($total_spent, 0); ?></div>
            <div class="stat-label">Total Spent</div>
        </div>
    </div>

    <?php if (!empty($all_orders)): ?>
    <div class="orders-grid">
        <?php foreach($all_orders as $order): $order_total = ($order['price']??0)*$order['quantity']; ?>
        <div class="order-card">
            <div class="order-card-head">
                <div>
                    <span class="order-id">Order #<?php echo $order['order_id']; ?></span>
                    <span class="payment-badge" style="margin-left:12px;"><?php echo $order['payment_method']; ?></span>
                </div>
                <span class="order-date"><i class="fas fa-calendar-alt"></i> <?php echo date('d M Y, h:i A', strtotime($order['order_datetime'])); ?></span>
            </div>
            <div class="order-card-body">
                <?php if (!empty($order['image_path'])): ?>
                    <img src="<?php echo htmlspecialchars($order['image_path']); ?>" class="order-img">
                <?php else: ?>
                    <div class="order-img-placeholder"><i class="fas fa-box"></i></div>
                <?php endif; ?>
                <div class="order-info">
                    <div class="order-product"><?php echo htmlspecialchars($order['product_name']); ?></div>
                    <div class="order-brand"><?php echo htmlspecialchars($order['brand']); ?></div>
                    <div class="order-meta">
                        <span>Qty: <strong><?php echo $order['quantity']; ?></strong></span>
                        <span>Unit: <strong>₹<?php echo number_format($order['price'],2); ?></strong></span>
                    </div>
                </div>
                <div class="order-total">₹<?php echo number_format($order_total, 2); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <div class="empty-icon"><i class="fas fa-receipt"></i></div>
        <h3>No Orders Yet</h3>
        <p>Start shopping to see your orders here.</p>
        <a href="index.php" class="btn-shop"><i class="fas fa-store"></i> Shop Now</a>
    </div>
    <?php endif; ?>
</div>
</body>
</html>
<?php $conn->close(); ?>
