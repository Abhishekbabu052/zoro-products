<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$user_id = $_SESSION['user_id'];
$query = "SELECT c.quantity as cart_quantity, p.* FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total = 0; $cart_items = [];
while($item = $result->fetch_assoc()) { $cart_items[] = $item; $total += $item['price'] * $item['cart_quantity']; }

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($cart_items)) {
    foreach($cart_items as $item) {
        $stmt = $conn->prepare("INSERT INTO orders (product_id, price, company_name, address, email, phone, quantity, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $pm = $_POST['payment_method'] == 'cod' ? 'Cash on Delivery' : 'Card Payment';
        $stmt->bind_param("idssssis", $item['product_id'], $item['price'], $_SESSION['company_name'], $_POST['address'], $_SESSION['email'], $_POST['phone'], $item['cart_quantity'], $pm);
        $stmt->execute();
        $us = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
        $us->bind_param("ii", $item['cart_quantity'], $item['product_id']); $us->execute();
    }
    $conn->prepare("DELETE FROM cart WHERE user_id = ?")->bind_param("i", $user_id);
    $ds = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $ds->bind_param("i", $user_id); $ds->execute();
    $_SESSION['order_message'] = "Order placed successfully!";
    header("Location: index.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);box-shadow:0 2px 16px rgba(160,106,0,.07);}
.header-inner{max-width:900px;margin:auto;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;}
.logo-name{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;text-decoration:none;}
.nav-links{display:flex;gap:16px;}
.nav-links a{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;display:flex;align-items:center;gap:5px;}
.nav-links a:hover{color:var(--gold-dark);}

.page-wrap{max-width:900px;margin:36px auto;padding:0 24px;}
.page-title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--text);margin-bottom:28px;}

.checkout-grid{display:grid;grid-template-columns:1fr 1.1fr;gap:24px;}

.panel{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;animation:fadeUp .4s ease both;}
.panel:nth-child(2){animation-delay:.1s;}
.panel-head{padding:18px 22px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;}
.panel-head h3{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;}
.panel-body{padding:22px;}

.cart-item-row{padding:10px 0;border-bottom:1px dashed var(--border);display:flex;justify-content:space-between;align-items:center;}
.cart-item-row:last-child{border-bottom:none;}
.item-name{font-size:14px;font-weight:700;color:var(--text);}
.item-qty-price{font-size:12px;color:var(--text-muted);margin-top:2px;}
.item-sub{font-size:15px;font-weight:700;color:var(--gold-dark);}
.total-row{display:flex;justify-content:space-between;align-items:center;padding:14px 0 0;margin-top:10px;border-top:2px solid var(--gold-pale);}
.total-label{font-size:16px;font-weight:700;}
.total-amount{font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--gold-dark);}

.form-group{margin-bottom:16px;}
.form-group label{display:block;margin-bottom:6px;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--gold-dark);}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:14px;color:var(--text);background:var(--bg);transition:border-color .2s,box-shadow .2s;}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--gold);box-shadow:0 0 0 3px rgba(200,150,12,.1);}
.form-group textarea{resize:vertical;min-height:80px;}
.submit-btn{width:100%;padding:14px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:8px;font-family:'Lato',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:opacity .2s,transform .1s;}
.submit-btn:hover{opacity:.9;transform:translateY(-1px);}
.back-link{display:block;text-align:center;margin-top:14px;color:var(--text-muted);font-size:13px;text-decoration:none;}
.back-link:hover{color:var(--gold-dark);}

.empty-state{text-align:center;padding:50px 24px;background:var(--surface);border:1px solid var(--border);border-radius:14px;}
.btn-shop{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--gold-dark);color:#fff;border-radius:7px;text-decoration:none;font-weight:700;margin-top:16px;}

@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:700px){.checkout-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="top-bar">✦ ZORO International ✦</div>
<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo-name">ZORO</a>
        <div class="nav-links">
            <a href="cart.php"><i class="fas fa-arrow-left"></i> Cart</a>
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>
</header>

<div class="page-wrap">
    <h1 class="page-title">Checkout</h1>

    <?php if (empty($cart_items)): ?>
        <div class="empty-state">
            <h3 style="font-family:'Playfair Display',serif;font-size:22px;margin-bottom:8px;">Your cart is empty</h3>
            <p style="color:var(--text-muted)">Add items to your cart before checking out.</p>
            <a href="index.php" class="btn-shop"><i class="fas fa-store"></i> Browse Products</a>
        </div>
    <?php else: ?>
        <div class="checkout-grid">
            <div class="panel">
                <div class="panel-head">
                    <h3><i class="fas fa-receipt"></i> Order Summary</h3>
                </div>
                <div class="panel-body">
                    <?php foreach($cart_items as $item): ?>
                        <div class="cart-item-row">
                            <div>
                                <div class="item-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                <div class="item-qty-price">Qty <?php echo $item['cart_quantity']; ?> × ₹<?php echo number_format($item['price'],2); ?></div>
                            </div>
                            <div class="item-sub">₹<?php echo number_format($item['price']*$item['cart_quantity'],2); ?></div>
                        </div>
                    <?php endforeach; ?>
                    <div class="total-row">
                        <span class="total-label">Total</span>
                        <span class="total-amount">₹<?php echo number_format($total,2); ?></span>
                    </div>
                </div>
            </div>

            <div class="panel">
                <div class="panel-head">
                    <h3><i class="fas fa-shipping-fast"></i> Delivery Details</h3>
                </div>
                <div class="panel-body">
                    <form method="POST">
                        <div class="form-group">
                            <label>Shipping Address</label>
                            <textarea name="address" placeholder="Full shipping address..." required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" name="phone" placeholder="+91 00000 00000" required>
                        </div>
                        <div class="form-group">
                            <label>Payment Method</label>
                            <select name="payment_method" required>
                                <option value="cod">Cash on Delivery</option>
                                <option value="card">Card Payment</option>
                            </select>
                        </div>
                        <button type="submit" class="submit-btn"><i class="fas fa-check-circle"></i> &nbsp;Place Order</button>
                    </form>
                    <a href="cart.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Cart</a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
<?php $conn->close(); ?>
