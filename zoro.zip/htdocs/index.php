<?php
session_start();

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$cart_count = 0;
$username_display = '';
$company = '';
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $cart_count = $row['total'] ?? 0;
    $stmt->close();
    $username_display = $_SESSION['contact_person_name'] ?? 'User';
    $company = $_SESSION['company_name'] ?? '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ZORO International — Premium Wholesale</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
html{scroll-behavior:smooth;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px 16px;}

.main-header{background:var(--surface);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;box-shadow:0 2px 20px rgba(160,106,0,.08);}
.header-inner{max-width:1280px;margin:auto;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;gap:24px;}
.logo{text-decoration:none;display:flex;flex-direction:column;gap:2px;}
.logo-name{font-family:'Playfair Display',serif;font-size:26px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;line-height:1;}
.logo-tagline{font-size:10px;letter-spacing:3px;color:var(--text-muted);text-transform:uppercase;}
.header-actions{display:flex;align-items:center;gap:24px;}
.cart-btn{position:relative;color:var(--text);text-decoration:none;font-size:22px;transition:color .2s;}
.cart-btn:hover{color:var(--gold);}
.cart-badge{position:absolute;top:-8px;right:-10px;background:var(--gold);color:#fff;font-size:10px;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;}
.user-block{display:flex;align-items:center;gap:10px;}
.user-avatar{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,var(--gold-light),var(--gold));color:var(--gold-dark);font-family:'Playfair Display',serif;font-weight:700;font-size:16px;display:flex;align-items:center;justify-content:center;border:2px solid var(--gold-pale);}
.user-name{font-size:14px;font-weight:700;color:var(--text);}
.user-company{font-size:11px;color:var(--text-muted);}
.logout-link{color:var(--text-muted);font-size:14px;text-decoration:none;transition:color .2s;margin-left:4px;}
.logout-link:hover{color:var(--gold-dark);}
.login-btn{padding:10px 22px;background:var(--gold-dark);color:#fff;border-radius:6px;text-decoration:none;font-size:13px;font-weight:700;letter-spacing:.8px;transition:background .2s,transform .1s;}
.login-btn:hover{background:var(--gold);transform:translateY(-1px);}

.main-nav{background:var(--surface);border-bottom:1px solid var(--border);}
.nav-inner{max-width:1280px;margin:auto;padding:0 24px;display:flex;}
.nav-link{padding:14px 20px;text-decoration:none;color:var(--text-muted);font-size:12px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;border-bottom:3px solid transparent;transition:all .2s;display:flex;align-items:center;gap:6px;}
.nav-link:hover,.nav-link.active{color:var(--gold-dark);border-bottom-color:var(--gold);}

.hero{position:relative;overflow:hidden;background:linear-gradient(135deg,#2a1f00 0%,#a06a00 55%,#c8960c 100%);padding:80px 24px;text-align:center;}
.hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 70% 50%,rgba(252,216,129,.15) 0%,transparent 60%);}
.hero-inner{position:relative;max-width:720px;margin:auto;}
.hero-badge{display:inline-block;background:rgba(252,216,129,.12);border:1px solid rgba(252,216,129,.35);color:var(--gold-light);font-size:11px;letter-spacing:3px;text-transform:uppercase;padding:6px 18px;border-radius:30px;margin-bottom:20px;animation:fadeUp .6s ease both;}
.hero h1{font-family:'Playfair Display',serif;font-size:clamp(34px,6vw,58px);font-weight:900;color:#fff;line-height:1.15;margin-bottom:18px;animation:fadeUp .7s .1s ease both;}
.hero h1 span{color:var(--gold-light);}
.hero p{font-size:16px;color:rgba(255,255,255,.72);line-height:1.7;margin-bottom:32px;animation:fadeUp .7s .2s ease both;}
.hero-cta{display:inline-flex;align-items:center;gap:10px;padding:14px 32px;background:var(--gold-light);color:var(--gold-dark);border-radius:6px;font-weight:700;font-size:14px;letter-spacing:.5px;text-decoration:none;transition:all .2s;animation:fadeUp .7s .3s ease both;}
.hero-cta:hover{background:#fff;transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.2);}
.hero-ring{position:absolute;border-radius:50%;border:1px solid rgba(252,216,129,.08);}
.hero-ring-1{width:400px;height:400px;top:-120px;left:-100px;}
.hero-ring-2{width:280px;height:280px;bottom:-80px;right:-60px;}

.features-strip{background:var(--surface);border-bottom:1px solid var(--border);padding:18px 24px;}
.features-inner{max-width:1280px;margin:auto;display:flex;justify-content:center;gap:48px;flex-wrap:wrap;}
.feature-item{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--text-muted);}
.feature-item i{color:var(--gold);font-size:18px;}
.feature-item strong{color:var(--text);}

.categories{max-width:1280px;margin:auto;padding:64px 24px;}
.section-header{text-align:center;margin-bottom:48px;}
.section-eyebrow{font-size:11px;letter-spacing:3px;text-transform:uppercase;color:var(--gold);font-weight:700;margin-bottom:10px;}
.section-title{font-family:'Playfair Display',serif;font-size:36px;font-weight:700;color:var(--text);}
.section-divider{width:60px;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));border-radius:2px;margin:16px auto 0;}

.categories-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:24px;}
.cat-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:32px 28px;position:relative;overflow:hidden;transition:transform .3s,box-shadow .3s,border-color .3s;}
.cat-card::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));transform:scaleX(0);transform-origin:left;transition:transform .3s;}
.cat-card:hover{transform:translateY(-6px);box-shadow:0 16px 48px rgba(160,106,0,.15);border-color:var(--gold-pale);}
.cat-card:hover::after{transform:scaleX(1);}
.card-icon{width:52px;height:52px;background:linear-gradient(135deg,var(--gold-pale),var(--gold-light));border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:18px;font-size:22px;color:var(--gold-dark);}
.cat-card h3{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--text);margin-bottom:8px;}
.cat-card p{font-size:14px;color:var(--text-muted);line-height:1.6;margin-bottom:22px;}
.cat-link{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;background:transparent;border:1.5px solid var(--gold-muted);color:var(--gold-dark);border-radius:6px;font-size:13px;font-weight:700;text-decoration:none;transition:all .2s;}
.cat-link:hover{background:var(--gold-dark);border-color:var(--gold-dark);color:#fff;gap:12px;}

.cat-card:nth-child(1){animation:fadeUp .5s .05s ease both;}
.cat-card:nth-child(2){animation:fadeUp .5s .1s ease both;}
.cat-card:nth-child(3){animation:fadeUp .5s .15s ease both;}
.cat-card:nth-child(4){animation:fadeUp .5s .2s ease both;}

.notification{max-width:1280px;margin:16px auto 0;padding:14px 20px;background:#fff8e1;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);border-radius:8px;color:var(--text);font-size:14px;display:flex;align-items:center;gap:10px;}

.footer{background:#2a1f00;color:rgba(252,216,129,.5);text-align:center;padding:20px;font-size:12px;letter-spacing:1px;margin-top:60px;}

@keyframes fadeUp{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:768px){.features-inner{gap:20px;}.hero{padding:50px 16px;}.categories{padding:40px 16px;}}
</style>
</head>
<body>

<div class="top-bar">✦ 100% Secure Delivery &nbsp;·&nbsp; Wholesale Prices Every Day &nbsp;·&nbsp; Premium Quality Guaranteed ✦</div>

<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo">
            <span class="logo-name">ZORO</span>
            <span class="logo-tagline">International</span>
        </a>
        <div class="header-actions">
            <a href="cart.php" class="cart-btn">
                <i class="fas fa-shopping-bag"></i>
                <span class="cart-badge"><?php echo $cart_count; ?></span>
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="user-block">
                    <div class="user-avatar"><?php echo strtoupper(substr($username_display, 0, 1)); ?></div>
                    <div>
                        <div class="user-name"><?php echo htmlspecialchars($username_display); ?></div>
                        <div class="user-company"><?php echo htmlspecialchars($company); ?></div>
                    </div>
                    <a href="logout.php" class="logout-link" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            <?php else: ?>
                <a href="login.php" class="login-btn">Login / Sign Up</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<nav class="main-nav">
    <div class="nav-inner">
        <a href="index.php" class="nav-link active"><i class="fas fa-home"></i> Home</a>
        <a href="#" class="nav-link"><i class="fas fa-info-circle"></i> About</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="view_orders.php" class="nav-link"><i class="fas fa-receipt"></i> My Orders</a>
        <?php endif; ?>
    </div>
</nav>

<?php if (isset($_SESSION['order_message'])): ?>
    <div class="notification">
        <i class="fas fa-check-circle" style="color:var(--gold)"></i>
        <?php echo $_SESSION['order_message']; unset($_SESSION['order_message']); ?>
    </div>
<?php endif; ?>

<section class="hero">
    <div class="hero-ring hero-ring-1"></div>
    <div class="hero-ring hero-ring-2"></div>
    <div class="hero-inner">
        <div class="hero-badge">✦ Premium Wholesale Marketplace</div>
        <h1>Quality Goods at <span>Wholesale</span> Prices</h1>
        <p>Your one-stop destination for premium food products, kitchen essentials, and beauty goods — sourced with care, priced for business.</p>
        <a href="#categories" class="hero-cta"><i class="fas fa-store"></i> Browse All Categories</a>
    </div>
</section>

<section class="features-strip">
    <div class="features-inner">
        <div class="feature-item"><i class="fas fa-shield-alt"></i><span><strong>Secure</strong> Payments</span></div>
        <div class="feature-item"><i class="fas fa-truck"></i><span><strong>Fast</strong> Delivery</span></div>
        <div class="feature-item"><i class="fas fa-boxes"></i><span><strong>Bulk</strong> Orders</span></div>
        <div class="feature-item"><i class="fas fa-star"></i><span><strong>Premium</strong> Quality</span></div>
    </div>
</section>

<section class="categories" id="categories">
    <div class="section-header">
        <div class="section-eyebrow">Our Collection</div>
        <h2 class="section-title">Shop By Category</h2>
        <div class="section-divider"></div>
    </div>
    <div class="categories-grid">
        <div class="cat-card">
            <div class="card-icon"><i class="fas fa-seedling"></i></div>
            <h3>Rice Varieties</h3>
            <p>Premium quality rice sourced from the finest farms around the world.</p>
            <a href="products/rice_varieties.php" class="cat-link">Shop Now <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="cat-card">
            <div class="card-icon"><i class="fas fa-mortar-pestle"></i></div>
            <h3>Rice Powder</h3>
            <p>Finely ground rice powder for traditional and modern cooking.</p>
            <a href="products/riceproducts.php" class="cat-link">Shop Now <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="cat-card">
            <div class="card-icon"><i class="fas fa-bread-slice"></i></div>
            <h3>Wheat Products</h3>
            <p>Fresh wheat flour and premium products for every kitchen.</p>
            <a href="products/wheat.php" class="cat-link">Shop Now <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="cat-card">
            <div class="card-icon"><i class="fas fa-leaf"></i></div>
            <h3>Pulses</h3>
            <p>Protein-rich lentils and beans, carefully selected and packed.</p>
            <a href="products/pulses.php" class="cat-link">Shop Now <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
</section>

<footer class="footer">© <?php echo date('Y'); ?> ZORO International &nbsp;·&nbsp; All Rights Reserved</footer>
</body>
</html>
