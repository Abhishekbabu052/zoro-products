<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{
    --bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;
    --gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;
    --text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;
    --sidebar-w:240px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh;}

.sidebar{width:var(--sidebar-w);position:fixed;top:0;left:0;height:100vh;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;z-index:200;box-shadow:4px 0 20px rgba(160,106,0,.07);}
.sidebar-brand{padding:26px 22px 18px;border-bottom:1px solid var(--border);}
.sidebar-logo{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;}
.sidebar-sub{font-size:9px;letter-spacing:3px;color:var(--text-muted);text-transform:uppercase;margin-top:3px;}
.sidebar-divider{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--gold-muted);padding:16px 22px 6px;font-weight:700;}
.sidebar-nav{flex:1;padding:6px 10px;overflow-y:auto;}
.sidebar-link{display:flex;align-items:center;gap:11px;padding:11px 13px;border-radius:8px;text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:all .2s;margin-bottom:2px;border:1.5px solid transparent;}
.sidebar-link i{width:17px;text-align:center;font-size:13px;}
.sidebar-link:hover{color:var(--gold-dark);background:rgba(240,223,160,.35);}
.sidebar-link.active{color:var(--gold-dark);background:var(--gold-pale);border-color:var(--gold-muted);}
.sidebar-footer{padding:14px 18px;border-top:1px solid var(--border);}
.logout-link{display:flex;align-items:center;gap:8px;text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;}
.logout-link:hover{color:#a00;}

.main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh;}
.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:11px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:7px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);padding:16px 28px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 12px rgba(160,106,0,.06);}
.main-header h1{font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--text);}
.header-meta{font-size:12px;color:var(--text-muted);}
.content{padding:26px;flex:1;}

.section{display:none;animation:fadeIn .25s ease;}
.section.active{display:block;}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px);}to{opacity:1;transform:translateY(0);}}

.msg{padding:13px 18px;border-radius:8px;margin-bottom:20px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px;transition:opacity .5s;}
.msg.success{background:#fffbee;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);color:var(--gold-dark);}
.msg.error{background:#fff0f0;border:1px solid #f5c6cb;border-left:4px solid #c00;color:#a00;}

.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px;}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px 22px;position:relative;overflow:hidden;animation:fadeUp .4s ease both;}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));}
.stat-num{font-family:'Playfair Display',serif;font-size:26px;font-weight:700;color:var(--gold-dark);}
.stat-label{font-size:12px;color:var(--text-muted);margin-top:4px;}

.form-panel{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:26px;}
.form-panel-head{padding:17px 22px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;display:flex;justify-content:space-between;align-items:center;}
.form-panel-head h3{font-family:'Playfair Display',serif;font-size:17px;font-weight:700;}
.form-panel-body{padding:22px;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.form-grid .full{grid-column:1/-1;}
.form-group{display:flex;flex-direction:column;gap:6px;}
.form-group label{font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--gold-dark);}
.form-group input,.form-group select,.form-group textarea{padding:10px 13px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:13px;color:var(--text);background:var(--bg);transition:border-color .2s,box-shadow .2s;outline:none;}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(200,150,12,.1);}
.form-group textarea{resize:vertical;min-height:90px;}
.form-group input[type="file"]{padding:7px 13px;}
.form-actions{display:flex;gap:10px;margin-top:18px;padding-top:18px;border-top:1px solid var(--border);}
.btn-primary{padding:10px 22px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:7px;font-family:'Lato',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:opacity .2s,transform .1s;}
.btn-primary:hover{opacity:.9;transform:translateY(-1px);}
.btn-secondary{padding:10px 22px;background:transparent;border:1.5px solid var(--border);color:var(--text-muted);border-radius:7px;font-family:'Lato',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;}
.btn-secondary:hover{border-color:var(--gold-muted);color:var(--text);}
.img-preview{max-width:70px;max-height:70px;object-fit:cover;border-radius:7px;border:1px solid var(--border);margin-top:5px;}

.table-panel{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;}
.table-panel-head{padding:14px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;}
.table-panel-head h3{font-family:'Playfair Display',serif;font-size:16px;font-weight:700;color:var(--text);}
.search-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;}
.search-wrap{position:relative;}
.search-wrap i{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--gold-muted);font-size:12px;}
.search-wrap input{padding:8px 13px 8px 32px;border:1.5px solid var(--border);border-radius:7px;font-family:'Lato',sans-serif;font-size:12px;color:var(--text);background:var(--bg);outline:none;transition:border-color .2s;width:200px;}
.search-wrap input:focus{border-color:var(--gold);}
.filter-select{padding:8px 12px;border:1.5px solid var(--border);border-radius:7px;font-family:'Lato',sans-serif;font-size:12px;color:var(--text);background:var(--bg);outline:none;cursor:pointer;}
.filter-select:focus{border-color:var(--gold);}
.btn-sm{padding:7px 13px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;border:none;font-family:'Lato',sans-serif;transition:all .2s;display:inline-flex;align-items:center;gap:4px;}
.btn-export{background:var(--gold-dark);color:#fff;text-decoration:none;}
.btn-export:hover{background:var(--gold);}
.btn-clear-sm{background:transparent;border:1.5px solid var(--border);color:var(--text-muted);}
.btn-clear-sm:hover{border-color:var(--gold-muted);}

table{width:100%;border-collapse:collapse;}
thead{background:linear-gradient(135deg,var(--gold-dark),#c8960c);}
th{padding:12px 15px;text-align:left;color:#fff;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;white-space:nowrap;}
td{padding:12px 15px;border-bottom:1px solid var(--border);font-size:13px;color:var(--text);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tbody tr:hover td{background:rgba(240,223,160,.15);}
.product-thumb{width:46px;height:46px;object-fit:cover;border-radius:7px;border:1px solid var(--border);}
.no-img{width:46px;height:46px;background:var(--bg);border:1px solid var(--border);border-radius:7px;display:flex;align-items:center;justify-content:center;color:var(--gold-muted);font-size:17px;}
.cell-name{font-weight:700;font-size:13px;color:var(--text);}
.cell-sub{font-size:11px;color:var(--text-muted);margin-top:2px;}
.price-cell{font-family:'Playfair Display',serif;font-weight:700;color:var(--gold-dark);}
.action-btns{display:flex;gap:5px;flex-wrap:wrap;}
.btn-edit{padding:5px 11px;background:var(--gold-pale);color:var(--gold-dark);border:1px solid var(--gold-muted);border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;transition:background .2s;}
.btn-edit:hover{background:var(--gold-light);}
.btn-del{padding:5px 11px;background:transparent;border:1px solid #f5c6cb;color:#a00;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;transition:background .2s;}
.btn-del:hover{background:#fff0f0;}
.btn-view{padding:5px 11px;background:rgba(13,71,161,.07);border:1px solid rgba(13,71,161,.18);color:#0d47a1;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;transition:background .2s;}
.btn-view:hover{background:rgba(13,71,161,.14);}
.payment-badge{padding:4px 9px;border-radius:20px;font-size:11px;font-weight:700;white-space:nowrap;}
.pay-cod{background:var(--gold-pale);color:var(--gold-dark);border:1px solid var(--gold-muted);}
.pay-card{background:rgba(13,71,161,.07);color:#0d47a1;border:1px solid rgba(13,71,161,.18);}
.status-badge{padding:4px 9px;border-radius:20px;font-size:11px;font-weight:700;background:#fff3e0;color:#bf6600;border:1px solid #fcd881;}
.empty-row td{text-align:center;padding:44px;color:var(--text-muted);}
.empty-row i{display:block;font-size:32px;color:var(--gold-pale);margin-bottom:10px;}

.profile-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;max-width:520px;}
.profile-head{background:linear-gradient(135deg,var(--gold-dark),var(--gold));padding:32px;text-align:center;color:#fff;}
.profile-avatar{width:64px;height:64px;border-radius:50%;background:rgba(255,255,255,.2);border:3px solid rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:26px;}
.profile-name{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;}
.profile-role{font-size:11px;opacity:.7;letter-spacing:1px;text-transform:uppercase;margin-top:3px;}
.profile-body{padding:24px;}
.profile-row{display:flex;justify-content:space-between;padding:11px 0;border-bottom:1px dashed var(--border);font-size:13px;}
.profile-row:last-child{border-bottom:none;}
.profile-row .lbl{color:var(--text-muted);font-weight:700;}
.profile-row .val{color:var(--text);font-weight:700;}
.system-ok{color:#27ae60;}

@keyframes fadeUp{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}
.stat-card:nth-child(1){animation-delay:.03s;}
.stat-card:nth-child(2){animation-delay:.06s;}
.stat-card:nth-child(3){animation-delay:.09s;}
@media(max-width:900px){.form-grid{grid-template-columns:1fr;}.sidebar{transform:translateX(-100%);}.main{margin-left:0;}}
</style>
</head>
<body>

<?php
session_start();

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname   = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$categories = [
    'Rice Varieties','Rice Powder','Wheat Products','Pulses','Pickles',
    'Spices','Readymade Curries/Gravies','Condiments','Snacks and Confectionary',
    'Frozen Food','Kitchen Utensils','Haircare and Beauty Products'
];
$brands = [
    'Ahaa','Anns','Anna','Butterfly','Chakson','Chandrika','Daawat',
    'Double Horse','Eastern','Godrej','Green Valley','Haldiram','Hamam',
    'Heer','Instant Delight','Kozhikodens','Kurkure','Lays','Lifebuoy',
    'Liril','Maggi','Medimix',"Mother's Choice",'Natco','Neptune',
    'Nilamels','Nirapara','Parachute','Parle','Pavizham','Preethi',
    'Prestige','Rexona','Sanam','Saras','SmartShop','StyleHub','Sujata',
    'Tasty Nibbles','Veetee','Village Farmer'
];

$message = ''; $error = ''; $editing_product = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Add / Update Product
    if (isset($_POST['add_product']) || isset($_POST['update_product'])) {
        $product_name     = trim($_POST['product_name']);
        $product_category = $_POST['product_category'];
        $brand            = $_POST['brand'];
        $price            = trim($_POST['price']);
        $quantity         = trim($_POST['quantity']);
        $description      = trim($_POST['description']);
        $product_id       = $_POST['product_id'] ?? null;

        if (empty($product_name)||empty($price)||empty($quantity)) {
            $error = "Product name, price and quantity are required!";
        } elseif (!is_numeric($price)||$price<=0) {
            $error = "Price must be a positive number!";
        } elseif (!is_numeric($quantity)||$quantity<0) {
            $error = "Quantity must be a non-negative number!";
        } else {
            $image_path = '';
            if (isset($_FILES['product_image'])&&$_FILES['product_image']['error']==UPLOAD_ERR_OK) {
                $upload_dir='product_images/';
                if(!file_exists($upload_dir)) mkdir($upload_dir,0777,true);
                $allowed=['image/jpeg','image/png','image/gif','image/webp'];
                if(in_array($_FILES['product_image']['type'],$allowed)){
                    $ext=pathinfo($_FILES['product_image']['name'],PATHINFO_EXTENSION);
                    $fn=uniqid().'_'.preg_replace('/[^a-zA-Z0-9]/','_',$product_name).'.'.$ext;
                    $target=$upload_dir.$fn;
                    if(move_uploaded_file($_FILES['product_image']['tmp_name'],$target)) $image_path=$target;
                    else $error="Failed to upload image.";
                } else { $error="Only JPG, PNG, GIF, WebP allowed."; }
            }
            if (empty($error)) {
                if (isset($_POST['add_product'])) {
                    $s=$conn->prepare("INSERT INTO products (product_name,product_category,brand,price,quantity,description,image_path) VALUES (?,?,?,?,?,?,?)");
                    $s->bind_param("sssdiss",$product_name,$product_category,$brand,$price,$quantity,$description,$image_path);
                    $message=$s->execute()?"Product added successfully!":"Failed: ".$s->error;
                    $s->close();
                } else {
                    if (!empty($image_path)) {
                        $s2=$conn->prepare("SELECT image_path FROM products WHERE product_id=?");
                        $s2->bind_param("i",$product_id); $s2->execute();
                        $r2=$s2->get_result()->fetch_assoc(); $s2->close();
                        if(!empty($r2['image_path'])&&file_exists($r2['image_path'])) unlink($r2['image_path']);
                        $s=$conn->prepare("UPDATE products SET product_name=?,product_category=?,brand=?,price=?,quantity=?,description=?,image_path=? WHERE product_id=?");
                        $s->bind_param("sssdissi",$product_name,$product_category,$brand,$price,$quantity,$description,$image_path,$product_id);
                    } else {
                        $s=$conn->prepare("UPDATE products SET product_name=?,product_category=?,brand=?,price=?,quantity=?,description=? WHERE product_id=?");
                        $s->bind_param("sssdisi",$product_name,$product_category,$brand,$price,$quantity,$description,$product_id);
                    }
                    $message=$s->execute()?"Product updated successfully!":"Failed: ".$s->error;
                    $s->close();
                }
            }
        }
    }
    // Delete Product
    if (isset($_POST['delete_product'])) {
        $pid=$_POST['product_id'];
        $s=$conn->prepare("SELECT image_path FROM products WHERE product_id=?");
        $s->bind_param("i",$pid); $s->execute();
        $r=$s->get_result()->fetch_assoc(); $s->close();
        if(!empty($r['image_path'])&&file_exists($r['image_path'])) unlink($r['image_path']);
        $s2=$conn->prepare("DELETE FROM products WHERE product_id=?");
        $s2->bind_param("i",$pid);
        $message=$s2->execute()?"Product deleted!":"Failed: ".$conn->error;
        $s2->close();
    }
    // Edit Product (load)
    if (isset($_POST['edit_product'])) {
        $pid=$_POST['product_id'];
        $s=$conn->prepare("SELECT * FROM products WHERE product_id=?");
        $s->bind_param("i",$pid); $s->execute();
        $editing_product=$s->get_result()->fetch_assoc();
        $s->close();
    }
    // Delete Order
    if (isset($_POST['delete_order'])) {
        $oid=intval($_POST['order_id']);
        $s=$conn->prepare("SELECT product_id,quantity FROM orders WHERE order_id=?");
        $s->bind_param("i",$oid); $s->execute();
        $r=$s->get_result(); $s->close();
        if($r->num_rows>0){
            $o=$r->fetch_assoc();
            $us=$conn->prepare("UPDATE products SET quantity=quantity+? WHERE product_id=?");
            $us->bind_param("ii",$o['quantity'],$o['product_id']); $us->execute(); $us->close();
            $ds=$conn->prepare("DELETE FROM orders WHERE order_id=?");
            $ds->bind_param("i",$oid);
            $message=$ds->execute()?"Order deleted!":"Failed: ".$conn->error;
            $ds->close();
        }
    }
}

$search=isset($_GET['search'])?$conn->real_escape_string($_GET['search']):'';
if(!empty($search)){
    $st="%$search%";
    $stmt=$conn->prepare("SELECT * FROM products WHERE product_name LIKE ? OR product_category LIKE ? OR brand LIKE ? OR description LIKE ? ORDER BY product_id DESC");
    $stmt->bind_param("ssss",$st,$st,$st,$st);
} else {
    $stmt=$conn->prepare("SELECT * FROM products ORDER BY product_id DESC");
}
$stmt->execute();
$products_result=$stmt->get_result();
$prod_count=$products_result->num_rows;
$stmt->close();

$orders_q="SELECT o.*,p.product_name,p.brand,p.price as unit_price FROM orders o LEFT JOIN products p ON o.product_id=p.product_id ORDER BY o.order_datetime DESC";
$orders_result=$conn->query($orders_q);
$total_orders=$orders_result->num_rows;
$total_revenue=0;
$all_orders=[];
while($o=$orders_result->fetch_assoc()){$all_orders[]=$o;$total_revenue+=($o['price']??$o['unit_price']??0)*$o['quantity'];}
?>

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo">ZORO</div>
        <div class="sidebar-sub">Admin Panel</div>
    </div>
    <div class="sidebar-divider">Navigation</div>
    <nav class="sidebar-nav">
        <a href="#" class="sidebar-link active" onclick="showSection('products',this)">
            <i class="fas fa-boxes"></i> Products
        </a>
        <a href="#" class="sidebar-link" onclick="showSection('orders',this)">
            <i class="fas fa-receipt"></i> Orders
        </a>
        <a href="#" class="sidebar-link" onclick="showSection('profile',this)">
            <i class="fas fa-user-shield"></i> Profile
        </a>
        <a href="index.php" class="sidebar-link">
            <i class="fas fa-store"></i> View Store
        </a>
    </nav>
    <div class="sidebar-footer">
        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</aside>

<!-- MAIN AREA -->
<div class="main">
    <div class="top-bar">✦ ZORO International — Admin Dashboard ✦</div>

    <div class="main-header">
        <h1 id="section-title">Products</h1>
        <span class="header-meta"><i class="fas fa-clock"></i> <?php echo date('d M Y, h:i A'); ?></span>
    </div>

    <div class="content">

        <?php if($message): ?>
            <div class="msg success" id="flash"><i class="fas fa-check-circle"></i><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="msg error" id="flash"><i class="fas fa-exclamation-circle"></i><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- ══ PRODUCTS ══ -->
        <div id="products" class="section active">

            <div class="form-panel">
                <div class="form-panel-head">
                    <h3><i class="fas fa-<?php echo $editing_product?'pen':'plus-circle'; ?>"></i>
                        &nbsp;<?php echo $editing_product?'Edit Product':'Add New Product'; ?></h3>
                    <?php if($editing_product): ?>
                        <button class="btn-secondary" style="padding:7px 14px;font-size:12px;" onclick="cancelEdit()">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    <?php endif; ?>
                </div>
                <div class="form-panel-body">
                    <form method="POST" enctype="multipart/form-data">
                        <?php if($editing_product): ?>
                            <input type="hidden" name="product_id" value="<?php echo $editing_product['product_id']; ?>">
                        <?php endif; ?>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Product Name <span style="color:#c00">*</span></label>
                                <input type="text" name="product_name" placeholder="e.g. Basmati Rice 5kg"
                                       value="<?php echo $editing_product?htmlspecialchars($editing_product['product_name']):''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Category <span style="color:#c00">*</span></label>
                                <select name="product_category" required>
                                    <option value="">Select Category</option>
                                    <?php foreach($categories as $cat): ?>
                                        <option value="<?php echo htmlspecialchars($cat); ?>"
                                            <?php echo($editing_product&&$editing_product['product_category']==$cat)?'selected':''; ?>>
                                            <?php echo htmlspecialchars($cat); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Brand <span style="color:#c00">*</span></label>
                                <select name="brand" required>
                                    <option value="">Select Brand</option>
                                    <?php foreach($brands as $b): ?>
                                        <option value="<?php echo htmlspecialchars($b); ?>"
                                            <?php echo($editing_product&&$editing_product['brand']==$b)?'selected':''; ?>>
                                            <?php echo htmlspecialchars($b); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Price (₹) <span style="color:#c00">*</span></label>
                                <input type="number" name="price" step="0.01" min="0" placeholder="0.00"
                                       value="<?php echo $editing_product?htmlspecialchars($editing_product['price']):''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Quantity <span style="color:#c00">*</span></label>
                                <input type="number" name="quantity" min="0" placeholder="0"
                                       value="<?php echo $editing_product?htmlspecialchars($editing_product['quantity']):''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Product Image</label>
                                <input type="file" name="product_image" accept="image/*">
                                <?php if($editing_product&&!empty($editing_product['image_path'])): ?>
                                    <img src="<?php echo htmlspecialchars($editing_product['image_path']); ?>" class="img-preview">
                                <?php endif; ?>
                            </div>
                            <div class="form-group full">
                                <label>Description</label>
                                <textarea name="description" placeholder="Short product description..."><?php echo $editing_product?htmlspecialchars($editing_product['description']):''; ?></textarea>
                            </div>
                        </div>
                        <div class="form-actions">
                            <?php if($editing_product): ?>
                                <button type="submit" name="update_product" class="btn-primary"><i class="fas fa-save"></i> Update Product</button>
                                <button type="button" onclick="cancelEdit()" class="btn-secondary">Cancel</button>
                            <?php else: ?>
                                <button type="submit" name="add_product" class="btn-primary"><i class="fas fa-plus"></i> Add Product</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <div class="table-panel">
                <div class="table-panel-head">
                    <h3 id="productCount">Product List (<?php echo $prod_count; ?>)</h3>
                    <div class="search-row">
                        <div class="search-wrap">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search products..."
                                   value="<?php echo htmlspecialchars($search); ?>" onkeyup="filterProducts()">
                        </div>
                        <button class="btn-sm btn-clear-sm" onclick="clearSearch()"><i class="fas fa-times"></i> Clear</button>
                    </div>
                </div>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr><th>Image</th><th>Product</th><th>Category</th><th>Brand</th><th>Price</th><th>Qty</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php if($prod_count>0): while($p=$products_result->fetch_assoc()): ?>
                            <tr data-name="<?php echo strtolower(htmlspecialchars($p['product_name'])); ?>"
                                data-category="<?php echo strtolower(htmlspecialchars($p['product_category'])); ?>"
                                data-brand="<?php echo strtolower(htmlspecialchars($p['brand'])); ?>"
                                data-description="<?php echo strtolower(htmlspecialchars($p['description'])); ?>">
                                <td>
                                    <?php if(!empty($p['image_path'])&&file_exists($p['image_path'])): ?>
                                        <img src="<?php echo htmlspecialchars($p['image_path']); ?>" class="product-thumb">
                                    <?php else: ?><div class="no-img"><i class="fas fa-image"></i></div><?php endif; ?>
                                </td>
                                <td><div class="cell-name"><?php echo htmlspecialchars($p['product_name']); ?></div></td>
                                <td><span style="font-size:11px;color:var(--text-muted);"><?php echo htmlspecialchars($p['product_category']); ?></span></td>
                                <td><?php echo htmlspecialchars($p['brand']); ?></td>
                                <td class="price-cell">₹<?php echo number_format($p['price'],2); ?></td>
                                <td><span style="font-weight:700;color:<?php echo $p['quantity']>0?'var(--gold-dark)':'#bbb'; ?>;"><?php echo $p['quantity']; ?></span></td>
                                <td>
                                    <div class="action-btns">
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="product_id" value="<?php echo $p['product_id']; ?>">
                                            <button type="submit" name="edit_product" class="btn-edit"><i class="fas fa-pen"></i> Edit</button>
                                        </form>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this product?');">
                                            <input type="hidden" name="product_id" value="<?php echo $p['product_id']; ?>">
                                            <button type="submit" name="delete_product" class="btn-del"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; else: ?>
                                <tr class="empty-row"><td colspan="7"><i class="fas fa-box-open"></i>No products found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ══ ORDERS ══ -->
        <div id="orders" class="section">
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-num"><?php echo $total_orders; ?></div><div class="stat-label"><i class="fas fa-receipt"></i> Total Orders</div></div>
                <div class="stat-card"><div class="stat-num">₹<?php echo number_format($total_revenue,2); ?></div><div class="stat-label"><i class="fas fa-coins"></i> Total Revenue</div></div>
                <div class="stat-card"><div class="stat-num"><?php echo date('M Y'); ?></div><div class="stat-label"><i class="fas fa-calendar"></i> Current Month</div></div>
            </div>

            <div class="table-panel">
                <div class="table-panel-head">
                    <h3>All Orders (<?php echo $total_orders; ?>)</h3>
                    <div class="search-row">
                        <div class="search-wrap">
                            <i class="fas fa-search"></i>
                            <input type="text" id="orderSearch" placeholder="Customer or product..." onkeyup="filterOrders()">
                        </div>
                        <select id="orderStatusFilter" class="filter-select" onchange="filterOrderStatus()">
                            <option value="">All Payments</option>
                            <option value="Cash on Delivery">Cash on Delivery</option>
                            <option value="Card Payment">Card Payment</option>
                        </select>
                        <button class="btn-sm btn-clear-sm" onclick="clearOrderSearch()"><i class="fas fa-times"></i></button>
                        <button class="btn-sm btn-export" onclick="exportOrders()"><i class="fas fa-download"></i> CSV</button>
                        <a href="view_orders.php" target="_blank" class="btn-sm btn-export"><i class="fas fa-external-link-alt"></i> Full View</a>
                    </div>
                </div>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr><th>#ID</th><th>Date</th><th>Product</th><th>Customer</th><th>Qty</th><th>Total</th><th>Payment</th><th>Status</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($all_orders)): foreach($all_orders as $order):
                                $odate=date('d M Y, h:i A',strtotime($order['order_datetime']));
                                $ototal=($order['price']??$order['unit_price']??0)*$order['quantity'];
                            ?>
                            <tr class="order-row"
                                data-payment="<?php echo $order['payment_method']; ?>"
                                data-customer="<?php echo strtolower($order['company_name'].' '.$order['email']); ?>"
                                data-product="<?php echo strtolower($order['product_name']); ?>">
                                <td><strong>#<?php echo str_pad($order['order_id'],6,'0',STR_PAD_LEFT); ?></strong></td>
                                <td style="font-size:11px;color:var(--text-muted);white-space:nowrap;"><?php echo $odate; ?></td>
                                <td>
                                    <div class="cell-name"><?php echo htmlspecialchars($order['product_name']); ?></div>
                                    <div class="cell-sub"><?php echo htmlspecialchars($order['brand']); ?></div>
                                </td>
                                <td>
                                    <div class="cell-name"><?php echo htmlspecialchars($order['company_name']); ?></div>
                                    <div class="cell-sub"><?php echo htmlspecialchars($order['email']); ?></div>
                                </td>
                                <td><?php echo $order['quantity']; ?></td>
                                <td class="price-cell">₹<?php echo number_format($ototal,2); ?></td>
                                <td><span class="payment-badge <?php echo $order['payment_method']=='Cash on Delivery'?'pay-cod':'pay-card'; ?>"><?php echo $order['payment_method']; ?></span></td>
                                <td><span class="status-badge">Pending</span></td>
                                <td>
                                    <div class="action-btns">
                                        <button onclick="viewOrderDetails(<?php echo $order['order_id']; ?>)" class="btn-view"><i class="fas fa-eye"></i></button>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete order? This will restore stock.');">
                                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                            <button type="submit" name="delete_order" class="btn-del"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; else: ?>
                                <tr class="empty-row"><td colspan="9"><i class="fas fa-receipt"></i>No orders yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ══ PROFILE ══ -->
        <div id="profile" class="section">
            <div class="profile-card">
                <div class="profile-head">
                    <div class="profile-avatar"><i class="fas fa-user-shield"></i></div>
                    <div class="profile-name">Administrator</div>
                    <div class="profile-role">ZORO International</div>
                </div>
                <div class="profile-body">
                    <div class="profile-row"><span class="lbl">System Status</span><span class="val system-ok"><i class="fas fa-circle" style="font-size:8px;"></i> Operational</span></div>
                    <div class="profile-row"><span class="lbl">Total Products</span><span class="val"><?php echo $prod_count; ?></span></div>
                    <div class="profile-row"><span class="lbl">Total Orders</span><span class="val"><?php echo $total_orders; ?></span></div>
                    <div class="profile-row"><span class="lbl">Total Revenue</span><span class="val" style="color:var(--gold-dark);font-family:'Playfair Display',serif;">₹<?php echo number_format($total_revenue,2); ?></span></div>
                    <div class="profile-row"><span class="lbl">Session</span><span class="val"><?php echo date('d M Y, h:i A'); ?></span></div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
const titles = {products:'Products', orders:'Orders', profile:'Admin Profile'};
function showSection(id, el) {
    event.preventDefault();
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.sidebar-link').forEach(a => a.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    if (el) el.classList.add('active');
    document.getElementById('section-title').textContent = titles[id]||id;
}
function cancelEdit() { window.location.href = window.location.pathname; }

function filterProducts() {
    const q = document.getElementById('searchInput').value.toLowerCase();
    let count = 0;
    document.querySelectorAll('#products table tbody tr:not(.empty-row)').forEach(r => {
        const ok = ['name','category','brand','description'].some(k=>(r.dataset[k]||'').includes(q));
        r.style.display = ok ? '' : 'none';
        if(ok) count++;
    });
    document.getElementById('productCount').textContent = `Product List (${count})`;
}
function clearSearch() { document.getElementById('searchInput').value=''; filterProducts(); }

function filterOrders() {
    const q = document.getElementById('orderSearch').value.toLowerCase();
    document.querySelectorAll('.order-row').forEach(r => {
        r.style.display=(r.dataset.customer.includes(q)||r.dataset.product.includes(q))?'':'none';
    });
}
function filterOrderStatus() {
    const f = document.getElementById('orderStatusFilter').value;
    document.querySelectorAll('.order-row').forEach(r => {
        r.style.display=(!f||r.dataset.payment===f)?'':'none';
    });
}
function clearOrderSearch() {
    document.getElementById('orderSearch').value='';
    document.getElementById('orderStatusFilter').value='';
    document.querySelectorAll('.order-row').forEach(r=>r.style.display='');
}

function viewOrderDetails(id) {
    alert('Order #' + id + '\n\nYou can implement a modal to show full order details here.');
}

function exportOrders() {
    let csv='Order ID,Date,Product,Customer,Qty,Total,Payment,Status\n';
    document.querySelectorAll('.order-row').forEach(r=>{
        if(r.style.display!=='none'){
            const c=r.querySelectorAll('td');
            csv+=[c[0],c[1],c[2].querySelector('.cell-name')?.textContent.trim(),
                  c[3].querySelector('.cell-name')?.textContent.trim(),c[4],c[5],c[6],c[7]]
                .map(v=>'"'+(v?.textContent||v||'').replace(/"/g,'""')+'"').join(',')+'\n';
        }
    });
    const a=document.createElement('a');
    a.href='data:text/csv;charset=utf-8,'+encodeURIComponent(csv);
    a.download='orders_'+new Date().toISOString().slice(0,10)+'.csv';
    a.click();
}

setTimeout(()=>document.querySelectorAll('.msg').forEach(m=>m.style.opacity='0'),5000);
document.addEventListener('DOMContentLoaded', filterProducts);
</script>
</body>
</html>
<?php $conn->close(); ?>