<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['remove_item'])) {
        $cart_id = intval($_POST['cart_id']);
        $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $cart_id, $user_id);
        $stmt->execute();
        $_SESSION['cart_message'] = "Item removed from cart.";
        header("Location: cart.php"); exit();
    }
    if (isset($_POST['clear_cart'])) {
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $_SESSION['cart_message'] = "Cart cleared.";
        header("Location: cart.php"); exit();
    }
    if (isset($_POST['order_all'])) {
        $query = "SELECT c.cart_id, c.product_id, c.quantity as cart_quantity, p.product_name, p.price, p.quantity as stock FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $cart_items = []; $total_amount = 0;
            while($item = $result->fetch_assoc()) {
                $cart_items[] = ['product_id'=>$item['product_id'],'product_name'=>$item['product_name'],'price'=>$item['price'],'quantity'=>$item['cart_quantity'],'stock'=>$item['stock']];
                $total_amount += $item['price'] * $item['cart_quantity'];
            }
            $_SESSION['cart_order_items'] = $cart_items;
            $_SESSION['cart_order_total'] = $total_amount;
            header("Location: order.php?source=cart"); exit();
        } else { $_SESSION['cart_error'] = "Your cart is empty!"; header("Location: cart.php"); exit(); }
    }
}

$query = "SELECT c.cart_id, c.quantity as cart_quantity, p.* FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Shopping Cart — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px 16px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);box-shadow:0 2px 20px rgba(160,106,0,.08);}
.header-inner{max-width:1100px;margin:auto;padding:18px 24px;display:flex;justify-content:space-between;align-items:center;}
.logo{text-decoration:none;}
.logo-name{font-family:'Playfair Display',serif;font-size:24px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;}
.logo-tagline{font-size:10px;letter-spacing:3px;color:var(--text-muted);text-transform:uppercase;}
.nav-links{display:flex;gap:20px;align-items:center;}
.nav-links a{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;letter-spacing:.3px;transition:color .2s;display:flex;align-items:center;gap:6px;}
.nav-links a:hover{color:var(--gold-dark);}

.page-header{max-width:1100px;margin:40px auto 0;padding:0 24px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:flex-end;}
.page-title{font-family:'Playfair Display',serif;font-size:30px;font-weight:700;color:var(--text);}
.page-title span{color:var(--gold);}

.layout{max-width:1100px;margin:32px auto;padding:0 24px;display:grid;grid-template-columns:1fr 340px;gap:28px;align-items:start;}

/* CART ITEMS */
.cart-items{display:flex;flex-direction:column;gap:16px;}
.cart-item{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px;display:flex;gap:18px;align-items:center;transition:box-shadow .2s,transform .2s;position:relative;overflow:hidden;}
.cart-item::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(180deg,var(--gold-dark),var(--gold-light));border-radius:3px 0 0 3px;}
.cart-item:hover{box-shadow:0 8px 32px rgba(160,106,0,.10);transform:translateY(-2px);}
.item-img{width:90px;height:90px;object-fit:cover;border-radius:10px;border:1px solid var(--border);flex-shrink:0;}
.item-img-placeholder{width:90px;height:90px;background:var(--bg);border:1px solid var(--border);border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--gold-muted);font-size:24px;flex-shrink:0;}
.item-body{flex:1;}
.item-name{font-family:'Playfair Display',serif;font-size:17px;font-weight:700;color:var(--text);margin-bottom:6px;}
.item-meta{display:flex;gap:16px;margin-top:4px;}
.item-meta span{font-size:13px;color:var(--text-muted);}
.item-price{font-size:18px;font-weight:700;color:var(--gold-dark);margin-top:8px;}
.item-actions{display:flex;flex-direction:column;gap:8px;flex-shrink:0;}
.btn-order-single{padding:9px 16px;background:var(--gold-dark);color:#fff;border:none;border-radius:7px;font-size:12px;font-weight:700;letter-spacing:.3px;cursor:pointer;transition:background .2s,transform .1s;white-space:nowrap;}
.btn-order-single:hover{background:var(--gold);transform:translateY(-1px);}
.btn-remove{padding:9px 16px;background:transparent;border:1.5px solid #f5c6cb;color:#a00;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;}
.btn-remove:hover{background:#fff0f0;border-color:#a00;}

/* SIDEBAR */
.cart-sidebar{position:sticky;top:90px;}
.summary-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;}
.summary-head{background:linear-gradient(135deg,var(--gold-dark),#c8960c);padding:20px 24px;color:#fff;}
.summary-head h3{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;}
.summary-head p{font-size:13px;opacity:.75;margin-top:3px;}
.summary-body{padding:24px;}
.summary-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;font-size:14px;color:var(--text-muted);border-bottom:1px dashed var(--border);}
.summary-row:last-of-type{border-bottom:none;}
.summary-row.total{font-size:18px;font-weight:700;color:var(--text);padding-top:14px;margin-top:6px;border-top:2px solid var(--gold-pale);}
.summary-row.total span:last-child{color:var(--gold-dark);}
.btn-order-all{width:100%;padding:14px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:8px;font-family:'Lato',sans-serif;font-size:14px;font-weight:700;cursor:pointer;transition:opacity .2s,transform .1s;margin-top:16px;letter-spacing:.3px;}
.btn-order-all:hover{opacity:.9;transform:translateY(-1px);}
.btn-clear{width:100%;padding:11px;background:transparent;border:1.5px solid var(--border);color:var(--text-muted);border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;margin-top:10px;transition:all .2s;}
.btn-clear:hover{border-color:#f5c6cb;color:#a00;}

/* NOTIFICATIONS */
.flash{max-width:1100px;margin:16px auto 0;padding:0 24px;}
.flash-msg{padding:13px 18px;border-radius:8px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px;margin-bottom:12px;}
.flash-success{background:#fffbee;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);color:var(--gold-dark);}
.flash-error{background:#fff0f0;border:1px solid #f5c6cb;border-left:4px solid #c00;color:#a00;}

/* EMPTY */
.empty-state{grid-column:1/-1;text-align:center;padding:60px 24px;background:var(--surface);border:1px solid var(--border);border-radius:16px;}
.empty-icon{font-size:52px;color:var(--gold-pale);margin-bottom:16px;}
.empty-state h3{font-family:'Playfair Display',serif;font-size:24px;color:var(--text);margin-bottom:8px;}
.empty-state p{color:var(--text-muted);margin-bottom:24px;}
.btn-browse{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--gold-dark);color:#fff;border-radius:7px;text-decoration:none;font-weight:700;font-size:14px;transition:background .2s;}
.btn-browse:hover{background:var(--gold);}

@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
.cart-item{animation:fadeUp .4s ease both;}
.cart-item:nth-child(1){animation-delay:.03s;}
.cart-item:nth-child(2){animation-delay:.06s;}
.cart-item:nth-child(3){animation-delay:.09s;}
.cart-item:nth-child(4){animation-delay:.12s;}

@media(max-width:900px){.layout{grid-template-columns:1fr;}.cart-sidebar{position:static;}}
</style>
</head>
<body>

<div class="top-bar">✦ ZORO International — Premium Wholesale ✦</div>

<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo">
            <div class="logo-name">ZORO</div>
            <div class="logo-tagline">International</div>
        </a>
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
            <a href="view_orders.php"><i class="fas fa-receipt"></i> My Orders</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</header>

<div class="page-header">
    <h1 class="page-title">Shopping <span>Cart</span></h1>
    <?php if ($result->num_rows > 0): ?>
        <span style="font-size:13px;color:var(--text-muted);"><?php echo $result->num_rows; ?> item<?php echo $result->num_rows > 1 ? 's' : ''; ?></span>
    <?php endif; ?>
</div>

<?php
$has_msg = isset($_SESSION['cart_message']) || isset($_SESSION['cart_error']);
if ($has_msg): ?>
<div class="flash">
    <?php if (isset($_SESSION['cart_message'])): ?>
        <div class="flash-msg flash-success"><i class="fas fa-check-circle"></i><?php echo $_SESSION['cart_message']; unset($_SESSION['cart_message']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['cart_error'])): ?>
        <div class="flash-msg flash-error"><i class="fas fa-exclamation-circle"></i><?php echo $_SESSION['cart_error']; unset($_SESSION['cart_error']); ?></div>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="layout">
<?php if ($result->num_rows > 0):
    $subtotal = 0; $item_count = 0;
    $all_items = [];
    while($item = $result->fetch_assoc()) {
        $all_items[] = $item;
        $subtotal += $item['price'] * $item['cart_quantity'];
        $item_count++;
    }
?>
    <div class="cart-items">
        <?php foreach($all_items as $item): $item_total = $item['price'] * $item['cart_quantity']; ?>
        <div class="cart-item">
            <?php if (!empty($item['image_path']) && file_exists($item['image_path'])): ?>
                <img src="<?php echo htmlspecialchars($item['image_path']); ?>" alt="" class="item-img">
            <?php else: ?>
                <div class="item-img-placeholder"><i class="fas fa-box"></i></div>
            <?php endif; ?>

            <div class="item-body">
                <div class="item-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                <div class="item-meta">
                    <span><i class="fas fa-tag" style="color:var(--gold-muted)"></i> <?php echo htmlspecialchars($item['brand']); ?></span>
                    <span>Qty: <strong><?php echo $item['cart_quantity']; ?></strong></span>
                    <span>Unit: ₹<?php echo number_format($item['price'], 2); ?></span>
                </div>
                <div class="item-price">₹<?php echo number_format($item_total, 2); ?></div>
            </div>

            <div class="item-actions">
                <button class="btn-order-single" onclick="window.location.href='order.php?product_id=<?php echo $item['product_id']; ?>&quantity=<?php echo $item['cart_quantity']; ?>'">
                    <i class="fas fa-bolt"></i> Order This
                </button>
                <form method="POST">
                    <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                    <button type="submit" name="remove_item" class="btn-remove" onclick="return confirm('Remove this item?')">
                        <i class="fas fa-trash-alt"></i> Remove
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <aside class="cart-sidebar">
        <div class="summary-card">
            <div class="summary-head">
                <h3>Order Summary</h3>
                <p><?php echo $item_count; ?> item<?php echo $item_count > 1 ? 's' : ''; ?> in your cart</p>
            </div>
            <div class="summary-body">
                <?php foreach($all_items as $item): ?>
                    <div class="summary-row">
                        <span><?php echo htmlspecialchars(substr($item['product_name'],0,22)).(strlen($item['product_name'])>22?'…':''); ?> ×<?php echo $item['cart_quantity']; ?></span>
                        <span>₹<?php echo number_format($item['price']*$item['cart_quantity'],2); ?></span>
                    </div>
                <?php endforeach; ?>
                <div class="summary-row total">
                    <span>Total Amount</span>
                    <span>₹<?php echo number_format($subtotal, 2); ?></span>
                </div>
                <form method="POST">
                    <button type="submit" name="order_all" class="btn-order-all">
                        <i class="fas fa-shopping-bag"></i> &nbsp;Order All Items
                    </button>
                </form>
                <form method="POST" onsubmit="return confirm('Clear entire cart?')">
                    <button type="submit" name="clear_cart" class="btn-clear">
                        <i class="fas fa-times"></i> Clear Cart
                    </button>
                </form>
            </div>
        </div>
    </aside>

<?php else: ?>
    <div class="empty-state">
        <div class="empty-icon"><i class="fas fa-shopping-bag"></i></div>
        <h3>Your cart is empty</h3>
        <p>Browse our premium collection and add items to your cart.</p>
        <a href="index.php" class="btn-browse"><i class="fas fa-store"></i> Browse Products</a>
    </div>
<?php endif; ?>
</div>

</body>
</html>
<?php $conn->close(); ?>
