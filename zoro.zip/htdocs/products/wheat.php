<?php
session_start();

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

require_once '../cart_functions.php';

// ── Page config ──
$page_category  = 'Wheat Products';
$page_title     = 'Wheat Products';
$page_file      = 'wheat.php';
$page_icon      = 'fas fa-bread-slice';
$page_desc      = 'Fresh wheat flour and premium products for every kitchen';

// ── Add to cart ──
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']);
    $user_id    = $_SESSION['user_id'] ?? null;
    $res        = addToCart($conn, $user_id, $product_id);
    if ($res == "success")         { $_SESSION['cart_message'] = "Added to cart!"; }
    elseif ($res == "login_required") { header("Location: ../login.php"); exit(); }
    else                           { $_SESSION['cart_error'] = $res; }
    header("Location: " . $_SERVER['PHP_SELF'] . (isset($_GET['search']) ? '?search='.urlencode($_GET['search']) : '')); exit();
}

$cart_count   = isset($_SESSION['user_id']) ? getCartCount($conn, $_SESSION['user_id']) : 0;
$search       = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$brand_filter = isset($_GET['brand'])  ? $conn->real_escape_string($_GET['brand'])  : '';

$query = "SELECT * FROM products WHERE product_category = '$page_category'";
if ($search)       $query .= " AND (product_name LIKE '%$search%' OR brand LIKE '%$search%' OR description LIKE '%$search%')";
if ($brand_filter) $query .= " AND brand = '$brand_filter'";
$query .= " ORDER BY product_name";

$result        = $conn->query($query);
$brands_result = $conn->query("SELECT DISTINCT brand FROM products WHERE product_category = '$page_category' ORDER BY brand");
$all_products  = [];
while ($p = $result->fetch_assoc()) $all_products[] = $p;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $page_title; ?> — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

/* ── TOP BAR ── */
.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px;}

/* ── HEADER ── */
.main-header{background:var(--surface);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;box-shadow:0 2px 16px rgba(160,106,0,.08);}
.header-inner{max-width:1280px;margin:auto;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;gap:16px;}
.logo{text-decoration:none;display:flex;flex-direction:column;gap:2px;}
.logo-name{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;line-height:1;}
.logo-tag{font-size:9px;letter-spacing:3px;color:var(--text-muted);text-transform:uppercase;}
.header-nav{display:flex;align-items:center;gap:20px;}
.nav-link{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;display:flex;align-items:center;gap:5px;letter-spacing:.2px;}
.nav-link:hover{color:var(--gold-dark);}
.cart-wrap{position:relative;}
.cart-badge{position:absolute;top:-7px;right:-9px;background:var(--gold);color:#fff;font-size:10px;font-weight:700;width:17px;height:17px;border-radius:50%;display:flex;align-items:center;justify-content:center;}

/* ── CATEGORY HERO ── */
.cat-hero{background:linear-gradient(135deg,#2a1f00 0%,#a06a00 55%,#c8960c 100%);padding:40px 24px;position:relative;overflow:hidden;}
.cat-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse at 80% 50%,rgba(252,216,129,.12) 0%,transparent 60%);}
.cat-hero-inner{max-width:1280px;margin:auto;position:relative;display:flex;align-items:center;gap:16px;}
.cat-hero-icon{width:56px;height:56px;background:rgba(252,216,129,.15);border:1px solid rgba(252,216,129,.3);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--gold-light);flex-shrink:0;}
.cat-hero h1{font-family:'Playfair Display',serif;font-size:clamp(24px,4vw,36px);font-weight:900;color:#fff;}
.cat-hero p{font-size:14px;color:rgba(255,255,255,.65);margin-top:4px;}
.breadcrumb{max-width:1280px;margin:0 auto;padding:12px 24px;display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-muted);}
.breadcrumb a{color:var(--gold);text-decoration:none;}
.breadcrumb a:hover{color:var(--gold-dark);}

/* ── FILTERS ── */
.filters-wrap{max-width:1280px;margin:0 auto;padding:0 24px 20px;}
.filters-bar{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px 20px;display:flex;gap:12px;flex-wrap:wrap;align-items:center;}
.search-wrap{position:relative;flex:1;min-width:200px;}
.search-wrap i{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--gold-muted);font-size:13px;}
.search-wrap input{width:100%;padding:10px 14px 10px 36px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:13px;color:var(--text);background:var(--bg);transition:border-color .2s,box-shadow .2s;outline:none;}
.search-wrap input:focus{border-color:var(--gold);box-shadow:0 0 0 3px rgba(200,150,12,.1);}
.filter-select{padding:10px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:13px;color:var(--text);background:var(--bg);outline:none;transition:border-color .2s;cursor:pointer;}
.filter-select:focus{border-color:var(--gold);}
.result-count{font-size:13px;color:var(--text-muted);margin-left:auto;}

/* ── PRODUCT GRID ── */
.grid-wrap{max-width:1280px;margin:0 auto;padding:0 24px 48px;}
.products-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:22px;}

.product-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:transform .25s,box-shadow .25s,border-color .25s;animation:fadeUp .4s ease both;display:flex;flex-direction:column;}
.product-card:hover{transform:translateY(-5px);box-shadow:0 14px 40px rgba(160,106,0,.13);border-color:var(--gold-pale);}

.card-img-wrap{position:relative;overflow:hidden;height:170px;background:var(--bg);}
.product-image{width:100%;height:100%;object-fit:cover;transition:transform .35s;}
.product-card:hover .product-image{transform:scale(1.05);}
.img-placeholder{width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:var(--gold-muted);}
.img-placeholder i{font-size:32px;opacity:.4;}
.img-placeholder span{font-size:11px;opacity:.5;}
.stock-badge{position:absolute;top:10px;right:10px;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.in-stock{background:rgba(160,106,0,.12);color:var(--gold-dark);border:1px solid rgba(160,106,0,.2);}
.out-stock{background:rgba(150,150,150,.12);color:#888;border:1px solid rgba(150,150,150,.2);}

.card-body{padding:16px;flex:1;display:flex;flex-direction:column;}
.product-name{font-family:'Playfair Display',serif;font-size:15px;font-weight:700;color:var(--text);margin-bottom:4px;line-height:1.3;}
.product-brand{font-size:12px;color:var(--text-muted);margin-bottom:10px;display:flex;align-items:center;gap:4px;}
.product-brand i{color:var(--gold-muted);font-size:10px;}

.price-row{display:flex;align-items:baseline;gap:6px;margin-bottom:14px;margin-top:auto;}
.product-price{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--gold-dark);}
.price-label{font-size:11px;color:var(--text-muted);}

.card-actions{display:flex;gap:8px;}
.btn-cart{flex:1;padding:9px 0;background:transparent;border:1.5px solid var(--gold-muted);color:var(--gold-dark);border-radius:7px;font-family:'Lato',sans-serif;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:5px;}
.btn-cart:hover{background:var(--gold-pale);border-color:var(--gold);}
.btn-cart:disabled{border-color:#ddd;color:#bbb;cursor:not-allowed;background:none;}
.btn-buy{flex:1;padding:9px 0;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:7px;font-family:'Lato',sans-serif;font-size:12px;font-weight:700;cursor:pointer;transition:opacity .2s,transform .1s;display:flex;align-items:center;justify-content:center;gap:5px;}
.btn-buy:hover{opacity:.9;transform:translateY(-1px);}

/* ── TOAST NOTIFICATION ── */
.toast{position:fixed;top:24px;right:24px;padding:14px 20px;border-radius:10px;z-index:9999;display:flex;align-items:center;gap:10px;font-size:13px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.12);animation:slideIn .3s ease both;}
.toast-success{background:#fffbee;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);color:var(--gold-dark);}
.toast-error{background:#fff0f0;border:1px solid #f5c6cb;border-left:4px solid #c00;color:#a00;}
.toast-close{background:none;border:none;cursor:pointer;color:inherit;margin-left:8px;font-size:16px;opacity:.6;}
.toast-close:hover{opacity:1;}

/* ── EMPTY STATE ── */
.empty-state{grid-column:1/-1;text-align:center;padding:60px 24px;background:var(--surface);border:1px solid var(--border);border-radius:16px;}
.empty-icon{font-size:48px;color:var(--gold-pale);margin-bottom:16px;}
.empty-state h3{font-family:'Playfair Display',serif;font-size:22px;color:var(--text);margin-bottom:8px;}
.empty-state p{color:var(--text-muted);}

/* ── ANIMATIONS ── */
@keyframes fadeUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
@keyframes slideIn{from{transform:translateX(110%);opacity:0;}to{transform:translateX(0);opacity:1;}}
.product-card:nth-child(4n+1){animation-delay:.04s;}
.product-card:nth-child(4n+2){animation-delay:.08s;}
.product-card:nth-child(4n+3){animation-delay:.12s;}
.product-card:nth-child(4n+4){animation-delay:.16s;}

@media(max-width:1200px){.products-grid{grid-template-columns:repeat(3,1fr);}}
@media(max-width:900px){.products-grid{grid-template-columns:repeat(2,1fr);}}
@media(max-width:560px){.products-grid{grid-template-columns:1fr;}.header-nav .nav-link span{display:none;}}
</style>
</head>
<body>

<div class="top-bar">✦ ZORO International — Premium Wholesale ✦</div>

<header class="main-header">
    <div class="header-inner">
        <a href="../index.php" class="logo">
            <span class="logo-name">ZORO</span>
            <span class="logo-tag">International</span>
        </a>
        <nav class="header-nav">
            <a href="../index.php" class="nav-link"><i class="fas fa-home"></i><span>Home</span></a>
            <a href="../cart.php" class="nav-link cart-wrap">
                <i class="fas fa-shopping-bag"></i><span>Cart</span>
                <?php if ($cart_count > 0): ?>
                    <span class="cart-badge"><?php echo $cart_count; ?></span>
                <?php endif; ?>
            </a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="../view_orders.php" class="nav-link"><i class="fas fa-receipt"></i><span>Orders</span></a>
                <a href="../logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
            <?php else: ?>
                <a href="../login.php" class="nav-link"><i class="fas fa-sign-in-alt"></i><span>Login</span></a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<!-- Toast notifications -->
<?php if (isset($_SESSION['cart_message'])): ?>
    <div class="toast toast-success" id="toast">
        <i class="fas fa-check-circle"></i>
        <?php echo $_SESSION['cart_message']; unset($_SESSION['cart_message']); ?>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    </div>
<?php endif; ?>
<?php if (isset($_SESSION['cart_error'])): ?>
    <div class="toast toast-error" id="toast">
        <i class="fas fa-exclamation-circle"></i>
        <?php echo $_SESSION['cart_error']; unset($_SESSION['cart_error']); ?>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    </div>
<?php endif; ?>

<div class="cat-hero">
    <div class="cat-hero-inner">
        <div class="cat-hero-icon"><i class="<?php echo $page_icon; ?>"></i></div>
        <div>
            <h1><?php echo $page_title; ?></h1>
            <p><?php echo $page_desc; ?></p>
        </div>
    </div>
</div>

<div class="breadcrumb">
    <a href="../index.php">Home</a>
    <i class="fas fa-chevron-right" style="font-size:10px;"></i>
    <span><?php echo $page_title; ?></span>
</div>

<div class="filters-wrap">
    <div class="filters-bar">
        <div class="search-wrap">
            <i class="fas fa-search"></i>
            <input type="text" id="search" placeholder="Search <?php echo $page_title; ?>..."
                   value="<?php echo htmlspecialchars($search); ?>" onkeyup="doSearch()">
        </div>
        <select id="brand" class="filter-select" onchange="doFilter()">
            <option value="">All Brands</option>
            <?php while($b = $brands_result->fetch_assoc()): ?>
                <option value="<?php echo htmlspecialchars($b['brand']); ?>"
                    <?php echo ($brand_filter == $b['brand']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($b['brand']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        <span class="result-count"><?php echo count($all_products); ?> product<?php echo count($all_products)!=1?'s':''; ?> found</span>
    </div>
</div>

<div class="grid-wrap">
    <div class="products-grid">
        <?php if (!empty($all_products)): ?>
            <?php foreach($all_products as $product): ?>
            <div class="product-card">
                <div class="card-img-wrap">
                    <?php if (!empty($product['image_path']) && file_exists('../' . $product['image_path'])): ?>
                        <img src="<?php echo htmlspecialchars('../' . $product['image_path']); ?>"
                             alt="<?php echo htmlspecialchars($product['product_name']); ?>"
                             class="product-image">
                    <?php else: ?>
                        <div class="img-placeholder">
                            <i class="fas fa-box-open"></i>
                            <span>No Image</span>
                        </div>
                    <?php endif; ?>
                    <span class="stock-badge <?php echo $product['quantity'] > 0 ? 'in-stock' : 'out-stock'; ?>">
                        <?php echo $product['quantity'] > 0 ? 'In Stock' : 'Out of Stock'; ?>
                    </span>
                </div>

                <div class="card-body">
                    <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                    <div class="product-brand"><i class="fas fa-tag"></i><?php echo htmlspecialchars($product['brand']); ?></div>

                    <?php if ($product['quantity'] > 0): ?>
                        <div class="price-row">
                            <span class="product-price">₹<?php echo number_format($product['price'], 2); ?></span>
                            <span class="price-label">/ unit</span>
                        </div>
                        <div class="card-actions">
                            <form method="POST" style="flex:1;display:flex;">
                                <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                                <button type="submit" name="add_to_cart" class="btn-cart">
                                    <i class="fas fa-shopping-bag"></i> Cart
                                </button>
                            </form>
                            <button class="btn-buy" onclick="<?php echo isset($_SESSION['user_id']) ? "window.location.href='../order.php?product_id=".$product['product_id']."'" : "window.location.href='../login.php'"; ?>">
                                <i class="fas fa-bolt"></i> Buy Now
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="price-row"><span style="font-size:14px;color:#aaa;font-style:italic;">Out of Stock</span></div>
                        <div class="card-actions">
                            <button class="btn-cart" disabled><i class="fas fa-shopping-bag"></i> Cart</button>
                            <button class="btn-buy" style="opacity:.35;cursor:not-allowed;" disabled><i class="fas fa-bolt"></i> Buy Now</button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fas fa-search"></i></div>
                <h3>No <?php echo $page_title; ?> found</h3>
                <p>Try a different search term or clear the filters.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
const PAGE_FILE = '<?php echo $page_file; ?>';
function buildUrl() {
    const s = document.getElementById('search').value;
    const b = document.getElementById('brand').value;
    let url = PAGE_FILE + '?';
    if (s) url += 'search=' + encodeURIComponent(s);
    if (b) url += (s ? '&' : '') + 'brand=' + encodeURIComponent(b);
    return url;
}
function doSearch() {
    clearTimeout(window._st);
    window._st = setTimeout(() => { window.location.href = buildUrl(); }, 480);
}
function doFilter() { window.location.href = buildUrl(); }

// Auto-dismiss toast
setTimeout(() => { const t = document.getElementById('toast'); if (t) t.remove(); }, 5000);
</script>
</body>
</html>
<?php $conn->close(); ?>