<?php
$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_order'])) {
    $order_id = intval($_POST['order_id']);
    $stmt = $conn->prepare("SELECT product_id, quantity FROM orders WHERE order_id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $order = $result->fetch_assoc();
        $conn->prepare("UPDATE products SET quantity = quantity + ? WHERE product_id = ?")->bind_param("ii", $order['quantity'], $order['product_id']);
        $us = $conn->prepare("UPDATE products SET quantity = quantity + ? WHERE product_id = ?");
        $us->bind_param("ii", $order['quantity'], $order['product_id']); $us->execute();
        $ds = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
        $ds->bind_param("i", $order_id);
        $message = $ds->execute() ? "Order deleted successfully!" : "Failed: " . $conn->error;
        $message_type = $ds->execute() ? "success" : "error";
    }
    $stmt->close();
}

$query = "SELECT o.*, p.product_name, p.brand, p.image_path FROM orders o LEFT JOIN products p ON o.product_id = p.product_id ORDER BY o.order_datetime DESC";
$result = $conn->query($query);
$total_orders = $result->num_rows;
$all_orders = [];
$total_revenue = 0;
while($o = $result->fetch_assoc()) { $all_orders[] = $o; $total_revenue += ($o['price']??0)*$o['quantity']; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>All Orders — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);box-shadow:0 2px 16px rgba(160,106,0,.07);}
.header-inner{max-width:1280px;margin:auto;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;}
.logo-name{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;text-decoration:none;}
.nav-links{display:flex;gap:16px;align-items:center;}
.nav-links a{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;display:flex;align-items:center;gap:5px;}
.nav-links a:hover{color:var(--gold-dark);}
.export-btn{padding:9px 18px;background:var(--gold-dark);color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;transition:background .2s;}
.export-btn:hover{background:var(--gold);}

.page-wrap{max-width:1280px;margin:32px auto;padding:0 24px;}
.page-title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--text);margin-bottom:6px;}
.page-sub{font-size:13px;color:var(--text-muted);margin-bottom:24px;}

.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:24px;}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px 22px;position:relative;overflow:hidden;}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--gold-dark),var(--gold-light));}
.stat-num{font-family:'Playfair Display',serif;font-size:26px;font-weight:700;color:var(--gold-dark);}
.stat-label{font-size:12px;color:var(--text-muted);margin-top:4px;}

.filters-bar{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;gap:12px;flex-wrap:wrap;align-items:center;}
.filters-bar input,.filters-bar select{padding:10px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:13px;color:var(--text);background:var(--bg);outline:none;transition:border-color .2s;}
.filters-bar input:focus,.filters-bar select:focus{border-color:var(--gold);}
.filters-bar input{flex:1;min-width:200px;}

.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;}
table{width:100%;border-collapse:collapse;}
thead{background:linear-gradient(135deg,var(--gold-dark),#c8960c);}
th{padding:14px 16px;text-align:left;color:#fff;font-size:12px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;}
td{padding:14px 16px;border-bottom:1px solid var(--border);font-size:14px;color:var(--text);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr.order-row:hover td{background:rgba(240,223,160,.2);}
.product-cell{display:flex;align-items:center;gap:10px;}
.prod-img{width:40px;height:40px;object-fit:cover;border-radius:7px;border:1px solid var(--border);flex-shrink:0;}
.prod-name{font-weight:700;color:var(--text);font-size:13px;}
.payment-badge{padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;background:var(--gold-pale);color:var(--gold-dark);border:1px solid var(--gold-muted);white-space:nowrap;}
.btn-delete{padding:7px 14px;background:transparent;border:1.5px solid #f5c6cb;color:#a00;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;transition:all .2s;}
.btn-delete:hover{background:#fff0f0;}
.order-total{font-weight:700;color:var(--gold-dark);}

.msg{padding:14px 18px;border-radius:8px;margin-bottom:16px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px;}
.msg.success{background:#fffbee;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);color:var(--gold-dark);}
.msg.error{background:#fff0f0;border:1px solid #f5c6cb;border-left:4px solid #c00;color:#a00;}

@keyframes fadeUp{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}
.table-wrap{animation:fadeUp .4s ease both;}
@media(max-width:768px){th:nth-child(5),td:nth-child(5),th:nth-child(3),td:nth-child(3){display:none;}}
</style>
</head>
<body>
<div class="top-bar">✦ Admin Panel — ZORO International ✦</div>
<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo-name">ZORO</a>
        <div class="nav-links">
            <a href="admin.php"><i class="fas fa-boxes"></i> Products</a>
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
            <button class="export-btn" onclick="exportCSV()"><i class="fas fa-download"></i> Export CSV</button>
        </div>
    </div>
</header>

<div class="page-wrap">
    <h1 class="page-title">All Orders</h1>
    <p class="page-sub">Admin view — complete order history</p>

    <?php if (isset($message)): ?>
        <div class="msg <?php echo $message_type; ?>"><i class="fas fa-info-circle"></i><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-num"><?php echo $total_orders; ?></div>
            <div class="stat-label"><i class="fas fa-receipt"></i> Total Orders</div>
        </div>
        <div class="stat-card">
            <div class="stat-num">₹<?php echo number_format($total_revenue, 2); ?></div>
            <div class="stat-label"><i class="fas fa-coins"></i> Total Revenue</div>
        </div>
    </div>

    <div class="filters-bar">
        <input type="text" id="searchInput" placeholder="🔍  Search orders, customers, products..." onkeyup="filterTable()">
        <select id="paymentFilter" onchange="filterTable()">
            <option value="">All Payment Methods</option>
            <option value="Cash on Delivery">Cash on Delivery</option>
            <option value="Card Payment">Card Payment</option>
        </select>
    </div>

    <?php if (!empty($all_orders)): ?>
    <div class="table-wrap">
        <table id="ordersTable">
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>Date</th>
                    <th>Product</th>
                    <th>Customer</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($all_orders as $order): $order_total = ($order['price']??0)*$order['quantity']; ?>
                <tr class="order-row"
                    data-text="<?php echo strtolower($order['company_name'].' '.$order['product_name'].' '.$order['order_id']); ?>"
                    data-payment="<?php echo $order['payment_method']; ?>">
                    <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                    <td><?php echo date('d M Y', strtotime($order['order_datetime'])); ?></td>
                    <td>
                        <div class="product-cell">
                            <?php if (!empty($order['image_path'])): ?>
                                <img src="<?php echo htmlspecialchars($order['image_path']); ?>" class="prod-img">
                            <?php endif; ?>
                            <span class="prod-name"><?php echo htmlspecialchars($order['product_name']); ?></span>
                        </div>
                    </td>
                    <td><?php echo htmlspecialchars($order['company_name']); ?></td>
                    <td><?php echo $order['quantity']; ?></td>
                    <td class="order-total">₹<?php echo number_format($order_total,2); ?></td>
                    <td><span class="payment-badge"><?php echo $order['payment_method']; ?></span></td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Delete order #<?php echo $order['order_id']; ?>?')">
                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                            <button type="submit" name="delete_order" class="btn-delete"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
function filterTable() {
    const s = document.getElementById('searchInput').value.toLowerCase();
    const p = document.getElementById('paymentFilter').value;
    document.querySelectorAll('.order-row').forEach(r => {
        const textOk = !s || r.dataset.text.includes(s);
        const payOk = !p || r.dataset.payment === p;
        r.style.display = textOk && payOk ? '' : 'none';
    });
}

function exportCSV() {
    const rows = [['ID','Date','Product','Customer','Qty','Total','Payment']];
    document.querySelectorAll('.order-row').forEach(r => {
        if (r.style.display !== 'none') {
            const cells = r.querySelectorAll('td');
            rows.push([cells[0].innerText, cells[1].innerText, cells[2].innerText.trim(), cells[3].innerText, cells[4].innerText, cells[5].innerText, cells[6].innerText]);
        }
    });
    const csv = rows.map(r => r.map(c => '"'+c.replace(/"/g,'""')+'"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'orders_' + new Date().toISOString().slice(0,10) + '.csv';
    a.click();
}
</script>
</body>
</html>
<?php $conn->close(); ?>
