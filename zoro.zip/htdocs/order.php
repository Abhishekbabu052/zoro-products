<?php
session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$hostname = "sql100.infinityfree.com";
$username = "if0_41576406";
$password = "Irl4WePkLEH6jq";
$dbname = "if0_41576406_products";

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$conn->set_charset("utf8mb4");

$user_id = $_SESSION['user_id'];
$is_cart_order = isset($_GET['source']) && $_GET['source'] == 'cart';
$single_product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

$cart_items = []; $total_price = 0; $error = ''; $success = ''; $product = null;

if ($is_cart_order) {
    if (isset($_SESSION['cart_order_items']) && !empty($_SESSION['cart_order_items'])) {
        $cart_items = $_SESSION['cart_order_items'];
        $total_price = $_SESSION['cart_order_total'] ?? 0;
    } else { $error = "No items in cart to order!"; }
} elseif ($single_product_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $single_product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) die("Product not found");
    $product = $result->fetch_assoc();
    $stmt->close();
    if ($product['quantity'] <= 0) die("This product is out of stock");
    $quantity = isset($_GET['quantity']) ? intval($_GET['quantity']) : 1;
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['quantity'])) $quantity = intval($_POST['quantity']);
    $cart_items[] = ['product_id'=>$single_product_id,'product_name'=>$product['product_name'],'price'=>$product['price'],'quantity'=>$quantity];
    $total_price = $product['price'] * $quantity;
} else { header("Location: index.php"); exit(); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_name = trim($_POST['company_name']);
    $address = trim($_POST['address']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $payment_method = $_POST['payment_method'];
    if (!$is_cart_order && isset($_POST['quantity'])) {
        $quantity = intval($_POST['quantity']);
        $cart_items[0]['quantity'] = $quantity;
        $total_price = $product['price'] * $quantity;
    }
    if (empty($company_name) || empty($address) || empty($email) || empty($phone)) {
        $error = "All fields are required!";
    } elseif (!$is_cart_order && ($quantity <= 0 || $quantity > $product['quantity'])) {
        $error = "Quantity must be between 1 and " . $product['quantity'] . "!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address!";
    } else {
        $all_success = true;
        foreach ($cart_items as $item) {
            $check_stmt = $conn->prepare("SELECT quantity FROM products WHERE product_id = ?");
            $check_stmt->bind_param("i", $item['product_id']);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            if ($check_result->num_rows > 0) {
                $stock = $check_result->fetch_assoc()['quantity'];
                if ($item['quantity'] > $stock) { $error = "Only " . $stock . " items available for " . $item['product_name'] . "!"; $all_success = false; break; }
            } else { $error = "Product not found: " . $item['product_name']; $all_success = false; break; }
            $check_stmt->close();
        }
        if ($all_success) {
            foreach ($cart_items as $item) {
                $item_quantity = $item['quantity']; $item_price = $item['price'];
                $stmt = $conn->prepare("INSERT INTO orders (product_id, price, company_name, address, email, phone, quantity, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("idssssis", $item['product_id'], $item_price, $company_name, $address, $email, $phone, $item_quantity, $payment_method);
                if ($stmt->execute()) {
                    $update_stmt = $conn->prepare("UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
                    $update_stmt->bind_param("ii", $item_quantity, $item['product_id']);
                    $update_stmt->execute(); $update_stmt->close();
                    if ($is_cart_order) {
                        $delete_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
                        $delete_stmt->bind_param("ii", $user_id, $item['product_id']);
                        $delete_stmt->execute(); $delete_stmt->close();
                    }
                } else { $all_success = false; $error = "Failed to place order: " . $conn->error; break; }
                $stmt->close();
            }
            if ($all_success) {
                $success = "Order placed successfully! Total: ₹" . number_format($total_price, 2);
                if ($is_cart_order) { unset($_SESSION['cart_order_items']); unset($_SESSION['cart_order_total']); }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Place Order — ZORO International</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{--bg:#fdf6e3;--surface:#fff;--gold-dark:#a06a00;--gold:#c8960c;--gold-light:#fcd881;--gold-pale:#f0dfa0;--gold-muted:#c8b87a;--text:#2a1f00;--text-muted:#7a6530;--border:#f0dfa0;}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Lato',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

.top-bar{background:var(--gold-dark);color:var(--gold-light);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-align:center;padding:8px;}
.main-header{background:var(--surface);border-bottom:1px solid var(--border);box-shadow:0 2px 16px rgba(160,106,0,.07);}
.header-inner{max-width:960px;margin:auto;padding:16px 24px;display:flex;justify-content:space-between;align-items:center;}
.logo{text-decoration:none;}
.logo-name{font-family:'Playfair Display',serif;font-size:22px;font-weight:900;color:var(--gold-dark);letter-spacing:2px;}
.nav-links{display:flex;gap:18px;}
.nav-links a{text-decoration:none;color:var(--text-muted);font-size:13px;font-weight:700;transition:color .2s;display:flex;align-items:center;gap:5px;}
.nav-links a:hover{color:var(--gold-dark);}

.page-wrap{max-width:960px;margin:36px auto;padding:0 24px;}
.page-title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--text);margin-bottom:28px;}
.page-title span{color:var(--gold);}

.order-layout{display:grid;grid-template-columns:1fr 1fr;gap:24px;}

.panel{background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;animation:fadeUp .5s ease both;}
.panel-head{padding:18px 22px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;}
.panel-head h3{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;}
.panel-head p{font-size:12px;opacity:.75;margin-top:3px;}
.panel-body{padding:22px;}

.order-item-row{padding:10px 0;border-bottom:1px dashed var(--border);display:flex;justify-content:space-between;align-items:center;}
.order-item-row:last-child{border-bottom:none;}
.item-label{font-size:14px;font-weight:700;color:var(--text);}
.item-qty{font-size:12px;color:var(--text-muted);margin-top:3px;}
.item-subtotal{font-size:15px;font-weight:700;color:var(--gold-dark);}
.total-row{display:flex;justify-content:space-between;align-items:center;padding:14px 0 0;margin-top:10px;border-top:2px solid var(--gold-pale);}
.total-label{font-size:16px;font-weight:700;color:var(--text);}
.total-amount{font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--gold-dark);}

.form-group{margin-bottom:16px;}
.form-group label{display:block;margin-bottom:6px;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--gold-dark);}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Lato',sans-serif;font-size:14px;color:var(--text);background:var(--bg);transition:border-color .2s,box-shadow .2s;}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--gold);box-shadow:0 0 0 3px rgba(200,150,12,.1);}
.form-group textarea{resize:vertical;min-height:80px;}

.qty-row{display:flex;align-items:center;gap:10px;}
.qty-btn{width:36px;height:36px;border:1.5px solid var(--border);background:var(--bg);color:var(--gold-dark);border-radius:7px;font-size:16px;font-weight:700;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;}
.qty-btn:hover{background:var(--gold-pale);border-color:var(--gold-muted);}
.qty-input{width:70px;text-align:center;border:1.5px solid var(--border);border-radius:7px;padding:8px;font-size:15px;font-weight:700;background:var(--bg);}
.qty-max{font-size:12px;color:var(--text-muted);}

.btn-place{width:100%;padding:14px;background:linear-gradient(135deg,var(--gold-dark),var(--gold));color:#fff;border:none;border-radius:8px;font-family:'Lato',sans-serif;font-size:15px;font-weight:700;cursor:pointer;letter-spacing:.3px;transition:opacity .2s,transform .1s;margin-top:6px;}
.btn-place:hover{opacity:.9;transform:translateY(-1px);}

.msg{padding:14px 18px;border-radius:10px;margin-bottom:20px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:10px;}
.msg.success{background:#fffbee;border:1px solid var(--gold-pale);border-left:4px solid var(--gold);color:var(--gold-dark);}
.msg.error{background:#fff0f0;border:1px solid #f5c6cb;border-left:4px solid #c00;color:#a00;}

.success-state{text-align:center;padding:40px;}
.success-icon{width:70px;height:70px;background:linear-gradient(135deg,var(--gold-light),var(--gold));border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:28px;color:var(--gold-dark);}
.success-state h2{font-family:'Playfair Display',serif;font-size:24px;color:var(--text);margin-bottom:8px;}
.success-state p{color:var(--text-muted);margin-bottom:24px;}
.btn-continue{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--gold-dark);color:#fff;border-radius:7px;text-decoration:none;font-weight:700;transition:background .2s;}
.btn-continue:hover{background:var(--gold);}

@keyframes fadeUp{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}
.panel:nth-child(2){animation-delay:.1s;}
@media(max-width:700px){.order-layout{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="top-bar">✦ ZORO International — Premium Wholesale ✦</div>
<header class="main-header">
    <div class="header-inner">
        <a href="index.php" class="logo"><span class="logo-name">ZORO</span></a>
        <div class="nav-links">
            <a href="<?php echo $is_cart_order ? 'cart.php' : 'index.php'; ?>"><i class="fas fa-arrow-left"></i> Back</a>
            <a href="index.php"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>
</header>

<div class="page-wrap">
    <h1 class="page-title"><?php echo $is_cart_order ? 'Complete Your <span>Cart Order</span>' : 'Place Your <span>Order</span>'; ?></h1>

    <?php if ($success): ?>
        <div class="panel">
            <div class="success-state">
                <div class="success-icon"><i class="fas fa-check"></i></div>
                <h2>Order Placed Successfully!</h2>
                <p><?php echo $success; ?></p>
                <a href="index.php" class="btn-continue"><i class="fas fa-store"></i> Continue Shopping</a>
            </div>
        </div>
    <?php else: ?>
        <?php if ($error): ?>
            <div class="msg error"><i class="fas fa-exclamation-circle"></i><?php echo $error; ?></div>
        <?php endif; ?>
        <div class="order-layout">
            <!-- Summary -->
            <div class="panel">
                <div class="panel-head">
                    <h3><i class="fas fa-receipt"></i> Order Summary</h3>
                    <p><?php echo count($cart_items); ?> item<?php echo count($cart_items)>1?'s':''; ?></p>
                </div>
                <div class="panel-body">
                    <?php foreach($cart_items as $item): ?>
                        <div class="order-item-row">
                            <div>
                                <div class="item-label"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                <div class="item-qty">₹<?php echo number_format($item['price'],2); ?> × <?php echo $item['quantity']; ?></div>
                            </div>
                            <div class="item-subtotal">₹<?php echo number_format($item['price']*$item['quantity'],2); ?></div>
                        </div>
                    <?php endforeach; ?>
                    <div class="total-row">
                        <span class="total-label">Total Amount</span>
                        <span class="total-amount" id="priceDisplay">₹<?php echo number_format($total_price,2); ?></span>
                    </div>
                </div>
            </div>

            <!-- Form -->
            <div class="panel">
                <div class="panel-head">
                    <h3><i class="fas fa-shipping-fast"></i> Delivery Details</h3>
                    <p>Fill in your shipping information</p>
                </div>
                <div class="panel-body">
                    <form method="POST">
                        <?php if (!$is_cart_order): ?>
                        <div class="form-group">
                            <label>Quantity</label>
                            <div class="qty-row">
                                <button type="button" class="qty-btn" onclick="changeQty(-1)">−</button>
                                <input type="number" name="quantity" id="quantity" value="<?php echo $quantity; ?>" min="1" max="<?php echo $product['quantity']; ?>" class="qty-input" readonly>
                                <button type="button" class="qty-btn" onclick="changeQty(1)">+</button>
                                <span class="qty-max">Max: <?php echo $product['quantity']; ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" name="company_name" value="<?php echo htmlspecialchars($_SESSION['company_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Delivery Address</label>
                            <textarea name="address" placeholder="Full shipping address..." required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" name="phone" placeholder="+91 00000 00000" required>
                        </div>
                        <div class="form-group">
                            <label>Payment Method</label>
                            <select name="payment_method" required>
                                <option value="Cash on Delivery">Cash on Delivery</option>
                                <option value="Card Payment">Card Payment</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-place"><i class="fas fa-check-circle"></i> &nbsp;Confirm Order</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
<?php if (!$is_cart_order): ?>
const pricePerUnit = <?php echo $product['price']; ?>;
const maxQty = <?php echo $product['quantity']; ?>;
function changeQty(d) {
    const inp = document.getElementById('quantity');
    let v = parseInt(inp.value) + d;
    if (v >= 1 && v <= maxQty) {
        inp.value = v;
        document.getElementById('priceDisplay').textContent = '₹' + (pricePerUnit * v).toLocaleString('en-IN', {minimumFractionDigits:2});
    }
}
<?php endif; ?>
</script>
</body>
</html>
<?php $conn->close(); ?>
